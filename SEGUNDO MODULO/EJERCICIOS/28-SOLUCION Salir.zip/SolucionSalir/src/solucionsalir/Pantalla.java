/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionsalir;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    /* Un constructor predeterminado con las configuraciones de la ventana. */
    public Pantalla() {
        
        /* Configuraciones. */
        this.setTitle("Salir de la ventana");
        /* Tamaño de la ventana. */
        this.setSize(400, 200);
        /* Hacer que la ventana aparezca centrada en la pantalla. */
        this.setLocationRelativeTo(null);
        /* Comportamiento al cerrar la ventana. */
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Creamos el botón. */
        JButton bSalir = new JButton("Salir");
        /* Por hacer algo diferente, una clase interna anónima. */
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        /* Creamos el panel intermedio. */
        JPanel panel = new JPanel();
        
        /* Introducimos el botón en el panel. */
        panel.add(bSalir);
        
        /* Introducimos el panel en el ContentPane. */
        this.getContentPane().add(panel);
        
        /* Asociar el escuchador de la ventana. */
        EscuchadorVentana ev = new EscuchadorVentana();
        this.addWindowListener(ev);
        
    } // Fin del constructor.
    
    /* Una clase interna con el adaptador WindowAdapter para controlar el cierre
    a través de la x de la ventana. */
    public class EscuchadorVentana extends WindowAdapter {
        @Override
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    }
    
} // Fin de la clase.
