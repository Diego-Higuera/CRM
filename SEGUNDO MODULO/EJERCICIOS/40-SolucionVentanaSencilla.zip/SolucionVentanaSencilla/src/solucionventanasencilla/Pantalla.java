package solucionventanasencilla;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
        
        this.setTitle("Ventana sencilla");
        this.setSize(new Dimension(350,290));
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Panel principal. */
        JPanel panel = new JPanel();
        /* Le vamos a asignar un renderizador BorderLayout. */
        BorderLayout bl = new BorderLayout();
        panel.setLayout(bl);
        
        /* A la zona central vamos a volcar un panel con las etiquetas, los
        cuadros de texto y la casilla de verificación, con un FlowLayout de
        alineación izquierda. */
        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new FlowLayout(FlowLayout.LEFT,15,10));
        /* Creamos los componentes. */
        JLabel lblUsername = new JLabel("USERNAME");
        lblUsername.setPreferredSize(new Dimension(300,24));
        panelCentral.add(lblUsername);
        JTextField txtUsername = new JTextField();
        txtUsername.setPreferredSize(new Dimension(300,24));
        panelCentral.add(txtUsername);
        JLabel lblPassword = new JLabel("PASSWORD");
        lblPassword.setPreferredSize(new Dimension(300,24));
        panelCentral.add(lblPassword);
        JPasswordField pswPassword = new JPasswordField();
        pswPassword.setPreferredSize(new Dimension(300,24));
        pswPassword.setEchoChar('*');
        panelCentral.add(pswPassword);
        JCheckBox chkRemember = new JCheckBox("REMEMBER PASSWORD");
        panelCentral.add(chkRemember);
        panel.add(panelCentral,BorderLayout.CENTER);
        
        /* A la zona sur le volcamos un panel FlowLayout con los botones. */
        JPanel panelSur = new JPanel();
        panelSur.setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
        JButton btnOk = new JButton("OK");
        btnOk.setPreferredSize(new Dimension(90,35));
        btnOk.setBackground(new Color(82,190,128));
        btnOk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Leemos el contenido de los cuadros de texto. */
                String username = txtUsername.getText();
                String password = String.valueOf(pswPassword.getPassword());
                String mensaje;
                /* Compruebo si usuario y contraseña son correctos. */
                if ( username.equals("manolito") && password.equals("1234") ) {
                    /* Construimos el mensaje. */
                    mensaje = "Bienvenido al sistema.";
                    if ( chkRemember.isSelected() ) {
                        mensaje += " Recordar contraseña.";
                    }
                } else {
                    mensaje = "Usuario o contraseña no válidos.";
                }
                JOptionPane.showMessageDialog(
                        null, 
                        mensaje, 
                        "Comprobar usuario", 
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        panelSur.add(btnOk);
        JButton btnCancel = new JButton("CANCEL");
        btnCancel.setPreferredSize(new Dimension(90,35));
        btnCancel.setBackground(new Color(231,76,60));
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panelSur.add(btnCancel);
        panel.add(panelSur,BorderLayout.SOUTH);
        
        this.getContentPane().add(panel);
        
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
    } // Final del constructor.
    
} // Final de la clase.
