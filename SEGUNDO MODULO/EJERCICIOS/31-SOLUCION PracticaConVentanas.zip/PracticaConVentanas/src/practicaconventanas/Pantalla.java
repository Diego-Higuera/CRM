/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practicaconventanas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    /* Se revela necesario el declarar todos los elementos que tenemos que
    editar, como globales, en lugar de locales al constructor. */
    JButton bSalir;
    JMenuItem menuClic;
    
    /* Un contador de clics. */
    private int contadorClics = 5;
    
    /* Constructor de la ventana. */
    public Pantalla() {
        
        /* Configuraciones. */
        this.setTitle("Descontando clics");
        this.setSize(300, 100);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Contenido de la ventana. */
        
        /* Un botón. */
        bSalir = new JButton( mensaje() );
        EscuchadorClic eClic = new EscuchadorClic();
        bSalir.addActionListener(eClic);
        
        /* Un menú con la opción de reducir clics. */
        JMenuBar barraMenu = new JMenuBar();
        JMenu menuSalir = new JMenu("Salir");
        menuClic = new JMenuItem( mensaje() );
        menuClic.addActionListener(eClic);
        
        /* Panel intermedio */
        JPanel panel = new JPanel();
        
        /* Ahora, lo colocamos todo. */
        panel.add(bSalir);
        this.getContentPane().add(panel);
        
        menuSalir.add(menuClic);
        barraMenu.add(menuSalir);
        this.setJMenuBar(barraMenu);
        
        /* Escuchador de la ventana. */
        EscuchadorVentana ev = new EscuchadorVentana();
        this.addWindowListener(ev);
        
    } // Final del constructor.
    
    /* Un par de clases internas para los escuchadores de ventana, botón y
    menú. */
    
    public class EscuchadorVentana extends WindowAdapter {
        
        @Override
        public void windowClosing(WindowEvent e) {
            reducirClic();
        }
        
    } // Final de la clase EscuchadorVentana.
    
    public class EscuchadorClic implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            reducirClic();
        }
        
    } // Final del EscuchadorClic.
    
    /* Un método para lanzar el código de los escuchadores. */
    public void reducirClic() {
        
        /* Reducir el contador de clics. */
        contadorClics--;
        
        /* Editar el texto del botón y el menú con el nuevo número de clics. */
        bSalir.setText( mensaje() );
        menuClic.setText( mensaje() );
        
        /* Cuando lleguemos a cero, cerramos la aplicación con un mensajito. */
        if ( contadorClics == 0 ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Esto es el fin del mundo. ¡Sálvese quien pueda!", 
                    "Fin del mundo", 
                    JOptionPane.WARNING_MESSAGE);
            System.exit(0);
        }
        
    } // Final del método reducirClic().
    
    /* Método para construir el mensaje de los botones y menús. */
    public String mensaje() {
        return "Quedan " + contadorClics + " clics";
    } // Final del método mensaje().
    
} // Final de la clase.
