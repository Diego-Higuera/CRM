/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soluciondni;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class SolucionDni {
    
    private static String letras = "TRWAGMYFPDXBNJZSQVHLCKE";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Pido un número de dni. */
/*        String numeroDni = JOptionPane.showInputDialog(
                null, 
                "Escribe tu número de dni y te devuelvo la letra.", 
                "Escribe tu dni", 
                JOptionPane.QUESTION_MESSAGE);
        
        JOptionPane.showMessageDialog(
                null, 
                "Tu letra de NIE es: " + letraNie(numeroDni), 
                "Tu letra de NIE", 
                JOptionPane.INFORMATION_MESSAGE); */

        String dni = JOptionPane.showInputDialog(
                null, 
                "Escribe tu dni completo y compruebo la letra.", 
                "Escribe tu dni", 
                JOptionPane.QUESTION_MESSAGE);

        if ( comprobarLetra(dni) ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "La letra es correcta", 
                    "Comprobar letra", 
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(
                    null, 
                    "La letra es incorrecta", 
                    "Comprobar letra", 
                    JOptionPane.INFORMATION_MESSAGE);
            
        }


    } // Final del método main().
    
    /* Método para calcular la letra de un dni a partir de su número. */
    public static char letraDni( String numero ) {
        
        int resto = Integer.parseInt(numero) % 23;
        return letras.charAt(resto);
        
    }
    
    public static char letraNie( String numero ) {
        
        numero = numero.toUpperCase();
        
        String resultado;
        switch( numero.charAt(0) ) {
            case 'X':
                resultado = "0" + numero.substring(1);
                break;
            case 'Y':
                resultado = "1" + numero.substring(1);
                break;
            case 'Z':
                resultado = "2" + numero.substring(1);
                break;
            default:
                resultado = numero;
        }

        int resto = Integer.parseInt(resultado) % 23;
        return letras.charAt(resto);

    }
    
    public static boolean comprobarLetra( String dni ) {
        
        dni = dni.toUpperCase();
        
        /* Extraemos la letra. */
        char letra = dni.charAt(dni.length()-1);
        /* Extraemos el número. */
        String numero = dni.substring(0, dni.length()-1);
        
        char letraResultante = letraNie(numero);
        
        return letra == letraResultante;
    }
    
} // Final de la clase.
