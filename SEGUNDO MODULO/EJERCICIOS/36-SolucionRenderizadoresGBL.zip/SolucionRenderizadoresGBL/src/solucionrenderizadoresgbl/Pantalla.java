/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionrenderizadoresgbl;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
        
        this.setTitle("Renderizadores con GridLayout");
        this.setSize(600,600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        
        /* Solucion con GridBagLayout. */
        GridBagLayout gbl = new GridBagLayout();
        panel.setLayout(gbl);
        
        JPanel p1 = new JPanel();
        p1.setBackground(Color.BLACK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.weightx = 200;
        gbc.weighty = 100;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(p1,gbc);
        
        JPanel p2 = new JPanel();
        p2.setBackground(Color.BLUE);
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 2;
        gbc.weightx = 200;
        gbc.weighty = 200;
        panel.add(p2,gbc);
        
        JPanel p3 = new JPanel();
        p3.setBackground(Color.CYAN);
        gbc.gridx = 4;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 4;
        gbc.weightx = 200;
        gbc.weighty = 400;
        panel.add(p3,gbc);
        
        JPanel p4 = new JPanel();
        p4.setBackground(Color.DARK_GRAY);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.weightx = 200;
        gbc.weighty = 100;
        panel.add(p4,gbc);
        
        JPanel p5 = new JPanel();
        p5.setBackground(Color.GRAY);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 100;
        gbc.weighty = 100;
        panel.add(p5,gbc);
        
        JPanel p6 = new JPanel();
        p6.setBackground(Color.GREEN);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 100;
        gbc.weighty = 100;
        panel.add(p6,gbc);
        
        JPanel p7 = new JPanel();
        p7.setBackground(Color.LIGHT_GRAY);
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.gridheight = 2;
        gbc.weightx = 200;
        gbc.weighty = 200;
        panel.add(p7,gbc);
        
        JPanel p8 = new JPanel();
        p8.setBackground(Color.MAGENTA);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 100;
        gbc.weighty = 100;
        panel.add(p8,gbc);
        
        JPanel p9 = new JPanel();
        p9.setBackground(Color.ORANGE);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 100;
        gbc.weighty = 100;
        panel.add(p9,gbc);
        
        this.getContentPane().add(panel);
        
    } // Fin del constructor.
    
} // Final de la clase.
