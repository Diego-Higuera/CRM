/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionrenderizadoresgl;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
        
        this.setTitle("Renderizadores con GridLayout");
        this.setSize(600,600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        
        /* Solucion con GridLayout. */
        GridLayout glPanel = new GridLayout(1,3);
        panel.setLayout(glPanel);
        
        JPanel pIzquierda = new JPanel();
        pIzquierda.setBackground(Color.BLACK);
        GridLayout glIzquierda = new GridLayout(2,1);
        pIzquierda.setLayout(glIzquierda);
        JPanel pCentro = new JPanel();
        pCentro.setBackground(Color.BLUE);
        GridLayout glCentro = new GridLayout(2,1);
        pCentro.setLayout(glCentro);
        JPanel pDerecha = new JPanel();
        pDerecha.setBackground(Color.CYAN);
        
        panel.add(pIzquierda);
        panel.add(pCentro);
        panel.add(pDerecha);
        
        JPanel pIArriba = new JPanel();
        pIArriba.setBackground(Color.DARK_GRAY);
        GridLayout glIArriba = new GridLayout(2,1);
        pIArriba.setLayout(glIArriba);
        JPanel pIAbajo = new JPanel();
        pIAbajo.setBackground(Color.GRAY);
        GridLayout glIAbajo = new GridLayout(2,2);
        pIAbajo.setLayout(glIAbajo);
        
        pIzquierda.add(pIArriba);
        pIzquierda.add(pIAbajo);
        
        JPanel pCArriba = new JPanel();
        pCArriba.setBackground(Color.GREEN);
        JPanel pCAbajo = new JPanel();
        pCAbajo.setBackground(Color.LIGHT_GRAY);
        
        pCentro.add(pCArriba);
        pCentro.add(pCAbajo);
        
        JPanel pIAArriba = new JPanel();
        pIAArriba.setBackground(Color.MAGENTA);
        pIArriba.add(pIAArriba);
        JPanel pIAAbajo = new JPanel();
        pIAAbajo.setBackground(Color.ORANGE);
        pIArriba.add(pIAAbajo);
        
        JPanel pIA1 = new JPanel();
        pIA1.setBackground(Color.PINK);
        JPanel pIA2 = new JPanel();
        pIA2.setBackground(Color.RED);
        JPanel pIA3 = new JPanel();
        pIA3.setBackground(Color.WHITE);
        JPanel pIA4 = new JPanel();
        pIA4.setBackground(Color.YELLOW);
        
        pIAbajo.add(pIA1);
        pIAbajo.add(pIA2);
        pIAbajo.add(pIA3);
        pIAbajo.add(pIA4);
        
        this.getContentPane().add(panel);
        
    } // Fin del constructor.
    
} // Final de la clase.
