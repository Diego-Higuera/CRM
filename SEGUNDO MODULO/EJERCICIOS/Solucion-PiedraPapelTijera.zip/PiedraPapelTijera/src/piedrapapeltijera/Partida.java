/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piedrapapeltijera;

/**
 *
 * @author evang
 */
import javax.swing.*;
import java.awt.*;

public class Partida {
    private final Jugador[] jugadores;
    private final int puntosParaGanar;

    public Partida(Jugador jugador1, Jugador jugador2, int puntosParaGanar) {
        this.jugadores = new Jugador[]{jugador1, jugador2};
        this.puntosParaGanar = puntosParaGanar;
    }

    public void ronda() {
        Jugadas jugada1 = jugadores[0].realizarJugada();
        Jugadas jugada2 = jugadores[1].realizarJugada();

        int resultado = ganadorRonda(jugada1, jugada2);

        switch (resultado) {
            case 1:
                jugadores[0].sumarPunto();
                mostrarResultadoConImagen(jugadores[0].getNombre() + " gana esta ronda!", jugada1);
                break;
            case -1:
                jugadores[1].sumarPunto();
                mostrarResultadoConImagen(jugadores[1].getNombre() + " gana esta ronda!", jugada2);
                break;
            default:
                JOptionPane.showMessageDialog(null, "¡Empate en esta ronda!");
                break;
        }

        JOptionPane.showMessageDialog(null, this.toString());
    }

    private int ganadorRonda(Jugadas j1, Jugadas j2) {
        if (j1 == j2) return 0;
        if ((j1 == Jugadas.PIEDRA && j2 == Jugadas.TIJERA) ||
            (j1 == Jugadas.TIJERA && j2 == Jugadas.PAPEL) ||
            (j1 == Jugadas.PAPEL && j2 == Jugadas.PIEDRA)) {
            return 1;
        }
        return -1;
    }

    public boolean comprobarGanador() {
        for (int i = 0; i < jugadores.length; i++) {
            if (jugadores[i].getPuntos() >= puntosParaGanar &&
                Math.abs(jugadores[0].getPuntos() - jugadores[1].getPuntos()) >= 1) {
                finalizarPartida(i);
                return true;
            }
        }
        return false;
    }

    private void finalizarPartida(int ganadorIndex) {
        JOptionPane.showMessageDialog(null, "¡Felicidades " + jugadores[ganadorIndex].getNombre() +
                " has ganado la partida!\n" +
                "Puntuaciones finales:\n" + jugadores[0] + "\n" + jugadores[1]);
    }

    private void mostrarResultadoConImagen(String mensaje, Jugadas jugadaGanadora) {
        String rutaImagen = obtenerImagenPorJugada(jugadaGanadora);
        ImageIcon icono = new ImageIcon(rutaImagen);

        // Redimensionar la imagen para ajustarla al tamaño del JLabel
        Image imagen = icono.getImage().getScaledInstance(600, 400, Image.SCALE_SMOOTH);
        ImageIcon iconoRedimensionado = new ImageIcon(imagen);

        // Crear un JLabel para la imagen
        JLabel imagenLabel = new JLabel(iconoRedimensionado, JLabel.CENTER);

        // Crear un JLabel para el mensaje
        JLabel mensajeLabel = new JLabel(mensaje, JLabel.CENTER);
        mensajeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        mensajeLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Crear un panel principal para centrar la imagen y el texto
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(mensajeLabel, BorderLayout.NORTH); // Mensaje en la parte superior
        panel.add(imagenLabel, BorderLayout.CENTER); // Imagen centrada
        
        panel.setBackground(new Color(0xAF7AC5));

        // Mostrar el panel en un JOptionPane
        JOptionPane.showMessageDialog(null, panel, "Resultado", JOptionPane.PLAIN_MESSAGE);
    }
      
    private String obtenerImagenPorJugada(Jugadas jugada) {
        switch (jugada) {
            case PIEDRA:
                return "src/imagen/gana_piedra.png";
            case PAPEL:
                return "src/imagen/gana_papel.png";
            case TIJERA:
                return "src/imagen/gana_tijeras.png";
            default:
                return null;
        }
    }

    @Override
    public String toString() {
        return "Puntuaciones actuales:\n" + jugadores[0] + "\n" + jugadores[1] +
                "\nPuntos necesarios para ganar: " + puntosParaGanar;
    }
}
