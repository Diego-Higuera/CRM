/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piedrapapeltijera;

/**
 *
 * @author evang
 */

import javax.swing.*;
import java.awt.*;

public class PiedraPapelTijera {

    public static void inicio(String[] args) {
        // Muestra la ventana de instrucciones al inicio
        instrucciones ventana = new instrucciones();
        ventana.getContentPane().setBackground(new Color(0xC39BD3)); // Color azul claro
        ventana.setVisible(true);
    }

    static void iniciarJuego() {
        boolean seguirJugando;

        do {
            Jugador jugador1 = new Jugador();
            Jugador jugador2 = new Jugador("Ordenador", TipoJugador.ORDENADOR);

            int puntosParaGanar = 0;
            boolean entradaValida = false;

            while (!entradaValida) {
                try {
                    // Crear un panel para personalizar el cuadro de diálogo de entrada
                    JPanel inputPanel = new JPanel();
                    inputPanel.setBackground(new Color(240, 230, 140)); // Color amarillo claro
                    JLabel inputLabel = new JLabel("Introduce los puntos necesarios para ganar:");
                    inputPanel.add(inputLabel);

                    String input = JOptionPane.showInputDialog(null, inputPanel);
                    if (input == null) { // Si el usuario presiona "Cancelar"
                        JOptionPane.showMessageDialog(null, "Juego cancelado.");
                        return;
                    }
                    puntosParaGanar = Integer.parseInt(input);
                    if (puntosParaGanar > 0) {
                        entradaValida = true;
                    } else {
                        JOptionPane.showMessageDialog(null, "Por favor, introduce un número mayor que 0.");
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Por favor, introduce un número válido.");
                }
            }

            Partida partida = new Partida(jugador1, jugador2, puntosParaGanar);

            while (!partida.comprobarGanador()) {
                partida.ronda();
            }

            // Crear un panel personalizado con la imagen y la pregunta
            JPanel panel = new JPanel(new BorderLayout());
         
            panel.setPreferredSize(new Dimension(550, 550));
            panel.setBackground(new Color(0x0000));
            
            
            // Insertar la imagen
            ImageIcon icono = new ImageIcon("src/imagen/Nuevo_Juego.jpg"); // Cambia esta ruta por la real
            Image imagen = icono.getImage().getScaledInstance(500,500, Image.SCALE_SMOOTH);
            JLabel imagenLabel = new JLabel(new ImageIcon(imagen));
            imagenLabel.setHorizontalAlignment(SwingConstants.CENTER);

            // Añadir la imagen y el mensaje al panel
            panel.add(imagenLabel, BorderLayout.CENTER);
           

            // Mostrar el JOptionPane con botones "Sí" y "No"
            int respuesta = JOptionPane.showConfirmDialog(null, panel, "Resultado de la Partida",
                    JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);

            // Actualizar la variable `seguirJugando` según la respuesta
            seguirJugando = respuesta == JOptionPane.YES_OPTION;
        } while (seguirJugando);

        // Panel para mensaje de despedida con fondo personalizado
        JPanel finalPanel = new JPanel();
        JLabel finalLabel = new JLabel("¡Gracias por jugar! Hasta la próxima.", JLabel.CENTER);
        finalLabel.setFont(new Font("Arial", Font.BOLD, 18));
        finalLabel.setForeground(new Color(0x6C3483));
        finalPanel.add(finalLabel);

        JOptionPane.showMessageDialog(null, finalPanel, "Despedida", JOptionPane.PLAIN_MESSAGE);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

