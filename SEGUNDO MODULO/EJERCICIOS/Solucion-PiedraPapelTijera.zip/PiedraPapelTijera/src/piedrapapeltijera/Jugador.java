/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piedrapapeltijera;

/**
 *
 * @author evang
 */

import javax.swing.JOptionPane;
import java.util.Random;

public class Jugador {
    private final String nombre;
    private final TipoJugador tipo;
    private int puntos;

    // Constructor por defecto
    public Jugador() {
        this.nombre = JOptionPane.showInputDialog("Introduce el nombre del jugador:");
        String[] opciones = {"HUMANO", "ORDENADOR"};
        int seleccion = JOptionPane.showOptionDialog(null, "Selecciona el tipo de jugador:",
                "Tipo de Jugador", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
        this.tipo = seleccion == 0 ? TipoJugador.HUMANO : TipoJugador.ORDENADOR;
        this.puntos = 0;
    }

    // Constructor sobrecargado
    public Jugador(String nombre, TipoJugador tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.puntos = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoJugador getTipo() {
        return tipo;
    }

    public int getPuntos() {
        return puntos;
    }

    public void sumarPunto() {
        this.puntos++;
    }

    public Jugadas realizarJugada() {
        if (tipo == TipoJugador.ORDENADOR) {
            int opcion = new Random().nextInt(3);
            return Jugadas.values()[opcion];
        } else {
            String[] opciones = {"PIEDRA", "PAPEL", "TIJERA"};
            int seleccion = JOptionPane.showOptionDialog(null, "Selecciona tu jugada:",
                    "Jugada", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
            return Jugadas.values()[seleccion];
        }
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Tipo: " + tipo + ", Puntos: " + puntos;
    }
}