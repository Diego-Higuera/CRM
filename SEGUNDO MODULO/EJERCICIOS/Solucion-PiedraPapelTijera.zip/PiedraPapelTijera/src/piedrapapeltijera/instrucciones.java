/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piedrapapeltijera;

/**
 *
 * @author evang
 */

import javax.swing.*;
import java.awt.*;

public class instrucciones extends JFrame {

    public instrucciones() {
        // Configuración de la ventana
        this.setTitle("Instrucciones del Juego");
        this.setSize(850, 650);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Imagen de las instrucciones
        JLabel imagen = new JLabel();
        ImageIcon icono = new ImageIcon("src/imagen/instrucc.png"); // Cambia esto por la ruta de tu imagen
        imagen.setIcon(new ImageIcon(icono.getImage().getScaledInstance(710, 500, Image.SCALE_SMOOTH))); // Ajusta tamaño
        imagen.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(imagen, BorderLayout.CENTER);
        
        panel.setBackground(new Color(0xC39BD3));

        // Botón Siguiente
        JButton siguiente = new JButton("Siguiente");
        siguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dispose(); // Cierra la ventana de instrucciones
                PiedraPapelTijera.iniciarJuego(); // Llama al método que inicia el juego principal
            }
        });
        panel.add(siguiente, BorderLayout.SOUTH);

        // Añadir panel al frame
        this.getContentPane().add(panel);
    }

    public static void main(String[] args) {
        // Este main solo sirve para pruebas; el flujo real será desde PiedraPapelTijera
        instrucciones ventana = new instrucciones();
        ventana.setVisible(true);
    }
}