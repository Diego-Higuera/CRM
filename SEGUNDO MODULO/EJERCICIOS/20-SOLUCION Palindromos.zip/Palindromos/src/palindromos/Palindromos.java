/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindromos;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class Palindromos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Pedir una frase para comprobar si es palíndromo. */
        String frase = JOptionPane.showInputDialog(
                null, 
                "Inserte una frase para comprobar si es palíndromo", 
                "Comprobación", 
                JOptionPane.QUESTION_MESSAGE);

        if ( comprobarPalindromo(frase) ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "La frase es un palíndromo", 
                    "Resultado", 
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(
                    null, 
                    "La frase NO es un palíndromo", 
                    "Resultado", 
                    JOptionPane.INFORMATION_MESSAGE);
        }

    } // Fin del método main().
    
    public static boolean comprobarPalindromo( String frase ) {
        /* Tenemos que limpiar la frase hasta dejarla solamente con caracteres
        alfabéticos (de la 'a' a la 'z'). Eliminando espacios, tildes, signos
        de puntuación, etc. Desconocemos el conjunto completo de signos de
        puntuación que debemos eliminar, pero sí conocemos los caracteres que
        son válidos para la cadena final. */
        
        // System.out.println(frase);
        
        /* Pasamos la cadena a mayúsculas o minúsculas. */
        frase = frase.toLowerCase();
        // System.out.println(frase);
        
        /* Sustituir los acentos por sus letras correspondientes. No olvidar 
        la diéresis. */
        frase = frase.replace("á", "a");
        frase = frase.replace("é", "e");
        frase = frase.replace("í", "i");
        frase = frase.replace("ó", "o");
        frase = frase.replace("ú", "u");
        frase = frase.replace("ü", "u");
        // System.out.println(frase);
        
        /* Quitar espacios y signos de puntuación. */
        String validos = "abcdefghijklmnñopqrstuvwxyz";
        String limpia = "";
        for ( int c=0; c<frase.length(); c++ ) {
            if ( validos.indexOf(frase.charAt(c)) != -1 ) {
                limpia += frase.charAt(c);
            }
        }
        /* Al salir del bucle tenemos una cadena formada sólo por caracteres
        válidos para el resultado final. */
        // System.out.println(limpia);
        
        /* Dar la vuelta a la cadena para poder comparar derecho y revés. */
        String reves = "";
        for ( int c=limpia.length()-1; c>=0; c-- ) {
            reves += limpia.charAt(c);
        }
        // System.out.println(reves);
        
        return limpia.equals(reves);
        
    } // Fin del método comprobarPalindromo().
    
} // Fin de la clase.
