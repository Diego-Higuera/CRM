/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionelectrodomesticos;

import java.util.ArrayList;

/**
 *
 * @author mourelle
 */
public class SolucionElectrodomesticos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Instanciamos una lavadora. */
        Lavadora lavadora1 = new Lavadora(200.0f, Colores.ROJO, 
                Consumo.C, 20, 8);
        System.out.println(lavadora1.toString());
        
        /* Pruebo la televisión. */
        Television television1 = new Television(300.0f, Colores.GRIS, 
                Consumo.A, 12, 60, true);
        System.out.println(television1.toString());
        
        
        /* Un ArrayList de electrodomesticos. */
        ArrayList<Electrodomesticos> electrodomesticos = new ArrayList();
        electrodomesticos.add(new Lavadora(150.0f, Colores.GRIS, 
                Consumo.B, 15, 12));
        electrodomesticos.add(new Television(400.0f, Colores.NEGRO, 
                Consumo.A, 20, 80, false));
        electrodomesticos.add(new Lavadora(120.0f, Colores.AZUL, 
                Consumo.B, 13, 6));
        
        for( int i=0; i<electrodomesticos.size(); i++ ) {
            System.out.println(electrodomesticos.get(i).toString());
        }
        
        
    } // Final del main()
    
} // Final de la clase
