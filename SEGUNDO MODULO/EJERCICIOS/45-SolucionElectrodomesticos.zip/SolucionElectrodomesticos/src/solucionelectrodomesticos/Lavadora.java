/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionelectrodomesticos;

/**
 *
 * @author mourelle
 */
public final class Lavadora extends Electrodomesticos {
    
    /* Atributos. */
    private final int carga;
    
    /* Constructor por defecto. */
    public Lavadora() {
        super();
        carga = 5;
    }
    
    public Lavadora(float precioBase, int peso) {
        super(precioBase, peso);
        carga = 5;
    }
    
    public Lavadora(float precioBase, Colores color, Consumo consumoEnergetico, 
            int peso, int carga) {
        super(precioBase, color, consumoEnergetico, peso);
        this.carga = carga;
    }
    
    /* Accesores. */
    public int getCarga() {
        return carga;
    }
    
    /* Método toString. */
    public String toString() {
        String resultado = "DATOS DE LA LAVADORA\n";
        resultado += "--------------------\n";
        resultado += super.toString();
        resultado += "Carga: " + carga + "\n";
        resultado += "Precio final: " + this.precioFinal();
        
        return resultado;
    }
    
    
    
    /* Otros métodos. */
    @Override
    public float precioFinal() {
        float precioF = super.precioFinal();
        
        if( carga > 30 ) {
            precioF += 50.0f;
        }
        
        return precioF;
    }
        
} // Final de la clase
