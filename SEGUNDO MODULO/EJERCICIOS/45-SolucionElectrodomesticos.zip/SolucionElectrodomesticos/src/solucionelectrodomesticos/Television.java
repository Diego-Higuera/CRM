/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionelectrodomesticos;

/**
 *
 * @author mourelle
 */
public final class Television extends Electrodomesticos {
    
    /* Atributos. */
    private final int resolucion;
    private final boolean sintonizadorTdt;
    
    /* Constructor por defecto. */
    public Television() {
        super();
        resolucion = 20;
        sintonizadorTdt = false;
    }
    
    public Television(float precioBase, int peso) {
        super(precioBase, peso);
        resolucion = 20;
        sintonizadorTdt = false;
    }
    
    public Television(float precioBase, Colores color, 
            Consumo consumoEnergetico, int peso, int resolucion, 
            boolean sintonizadorTdt) {
    
            super(precioBase, color, consumoEnergetico, peso);
            this.resolucion = resolucion;
            this.sintonizadorTdt = sintonizadorTdt;
    }
    
    /* Accesores. */
    public int getResolucion() {
        return resolucion;
    }
    
    public boolean isSintonizadorTdt() {
        return sintonizadorTdt;
    }
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = "DATOS DE LA TELEVISIÓN\n";
        resultado += "----------------------\n";
        resultado += super.toString();
        resultado += "Resolucion: " + resolucion + "\n";
        resultado += "¿Incluye sintonizador TDT? ";
        if( sintonizadorTdt ) {
            resultado += "SÍ";
        } else {
            resultado += "NO";
        }
        resultado += "\n";
        resultado += "Precio final: " + this.precioFinal();
        
        return resultado;
    }
    
    /* Otros métodos. */
    @Override
    public float precioFinal() {
        float precioF = super.precioFinal();
        if( resolucion > 40 ) {
            precioF += super.getPrecioBase() * 0.3;
        }
        
        if( sintonizadorTdt ) {
            precioF += 50.0;
        }
        
        return precioF;
    }
    
    
} // Final de la clase.
