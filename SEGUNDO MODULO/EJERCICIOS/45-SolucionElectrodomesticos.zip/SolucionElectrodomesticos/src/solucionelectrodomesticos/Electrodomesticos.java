/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionelectrodomesticos;

/**
 *
 * @author mourelle
 */
public abstract class Electrodomesticos {
    
    /* Atributos. */
    private final float precioBase;
    private final Colores color;
    private final Consumo consumoEnergetico;
    private final int peso;
    
    /* Constructor por defecto. */
    public Electrodomesticos() {
        precioBase = 100.0f;
        color = Colores.BLANCO;
        consumoEnergetico = Consumo.F;
        peso = 5;
    }
    
    /* Constructores sobrecargados. */
    public Electrodomesticos(float precioBase, int peso) {
        this.precioBase = precioBase;
        this.peso = peso;
        this.color = Colores.BLANCO;
        this.consumoEnergetico = Consumo.F;
    }
    
    public Electrodomesticos(float precioBase, Colores color, 
            Consumo consumoEnergetico, int peso ) {
        this.precioBase = precioBase;
        this.color = comprobarColor(color);
        this.consumoEnergetico = comprobarConsumoEnergetico(consumoEnergetico);
        this.peso = peso;
    }
    
    /* Accesores. */
    public float getPrecioBase() {
        return precioBase;
    }
    
    public Colores getColor() {
        return color;
    }
    
    public Consumo getConsumoEnergetico() {
        return consumoEnergetico;
    }
    
    public int getPeso() {
        return peso;
    }
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = "Precio base: " + precioBase + "\n";
        resultado += "Color: " + color + "\n";
        resultado += "Consumo energético: " + consumoEnergetico + "\n";
        resultado += "Peso: " + peso + "\n";
        
        return resultado;
    }
    
    /* Otras funciones. */
    private Consumo comprobarConsumoEnergetico(Consumo consumoEnergetico) {
        
        /* if( consumoEnergetico != Consumo.A &&
                consumoEnergetico != Consumo.B &&
                consumoEnergetico != Consumo.C &&
                consumoEnergetico != Consumo.D &&
                consumoEnergetico != Consumo.E &&
                consumoEnergetico != Consumo.F) {
            return Consumo.F;
        } else {
            return consumoEnergetico;
        } */
        for( Consumo c : Consumo.values() ) {
            if ( consumoEnergetico == c ) {
                return consumoEnergetico;
            }
        }
        /* Si pasado todo el bucle no ha devuelto nada, devolvemos F. */
        return Consumo.F;
        
    }
    
    private Colores comprobarColor(Colores color) {
        
        for( Colores c : Colores.values() ) {
            if ( color == c ) {
                return color;
            }
        }
        /* Si pasado todo el bucle no ha devuelto nada, devolvemos Blanco. */
        return Colores.BLANCO;
        
    }

    public float precioFinal() {
        
        float precioF = this.precioBase;
        
        switch(this.consumoEnergetico) {
            case A:
                precioF += 100.0f;
                break;
            case B:
                precioF += 80.0f;
                break;
            case C:
                precioF += 60.0f;
                break;
            case D:
                precioF += 50.0f;
                break;
            case E:
                precioF += 30.0f;
                break;
            case F:
                precioF += 10.0f;
                break;
        }
        
        if( peso <= 19 ) {
            precioF += 10.0f;
        } else if ( peso <= 49 ) {
            precioF += 50.0f;
        } else if ( peso <= 79 ) {
            precioF += 80.0f;
        } else {
            precioF += 100.0f;
        }
        
        return precioF;
        
    } // Final del método precioFinal.
    
    
    
    
    
    
    
    
} // Final de la clase.
