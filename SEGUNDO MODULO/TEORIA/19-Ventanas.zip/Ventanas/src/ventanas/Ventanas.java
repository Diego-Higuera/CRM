/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Ventanas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Creamos una ventana instanciando la clase JFrame. */
        JFrame ventana = new JFrame();
        
        /* Podemos configurar la ventana en algunos de sus aspectos, utilizando
        los accesores setter de la ventana. */
        
        /* Posición X e Y, ancho y alto. */
        ventana.setBounds(0, 0, 300, 100);
        /* Título de la ventana. */
        ventana.setTitle("Mi primera ventana");
        
        /* Comportamiento de la aplicación cuando se cierra la ventana. */
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /* Vamos a crear tres botones, los vamos a insertar en un contenedor
        intermedio y ese contenedor lo vamos a volcar en el ContentPane. */
        
        /* Creo los tres botones. */
        JButton b1, b2, b3;
        b1 = new JButton("Rojo");
        b2 = new JButton("Verde");
        b3 = new JButton("Azul");
        
        /* Creo un panel que sirva de contenedor intermedio. */
        JPanel panel = new JPanel();
        
        /* Añado los botones al panel. */
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        
        /* Ahora sólo me queda volcar el panel intermedio en el ContentPane. */
        ventana.getContentPane().add(panel);

        /* Hacemos visible la ventana. */
        ventana.setVisible(true);

    } // Fin del método main().
    
} // Final de la clase.
