/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unescuchadordosfuentes;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    /* Hacemos el panel global a toda la clase Pantalla. */
    JPanel panel;
    
    /* Constructor. */
    public Pantalla() {
        
        /* Configuraciones. */
        this.setTitle("Colores");
        this.setSize(300,100);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Componentes de la ventana. */
        
        /* Botones. */
        JButton bRojo, bVerde, bAzul;
        bRojo = new JButton("Rojo");
        bVerde = new JButton("Verde");
        bAzul = new JButton("Azul");
        /* Asociamos los escuchadores a los botones. */
        EscuchadorRojo escR = new EscuchadorRojo();
        bRojo.addActionListener(escR);
        EscuchadorVerde escV = new EscuchadorVerde();
        bVerde.addActionListener(escV);
        EscuchadorAzul escA = new EscuchadorAzul();
        bAzul.addActionListener(escA);
        
        /* Creamos el menú. */
        
        /* Barra de menús. */
        JMenuBar barraMenu = new JMenuBar();
        /* Menú para los colores. */
        JMenu menuColores = new JMenu("Colores");
        /* Elementos del menú. */
        JMenuItem menuRojo, menuVerde, menuAzul;
        menuRojo = new JMenuItem("Rojo");
        menuVerde = new JMenuItem("Verde");
        menuAzul = new JMenuItem("Azul");
        
        /* Ya no tengo que crear un nuevo escuchador rojo, ya que lo he creado
        anteriormente para el botón. Sólo asociar al menú. */
        menuRojo.addActionListener(escR);
        menuVerde.addActionListener(escV);
        menuAzul.addActionListener(escA);
        
        /* Introducimos los elementos de menú en el menú. */
        menuColores.add(menuRojo);
        menuColores.add(menuVerde);
        menuColores.add(menuAzul);
        /* Introducimos el menú en la barra. */
        barraMenu.add(menuColores);
        
        /* Panel intermedio. */
        panel = new JPanel();
        
        /* Insertar los botones en el panel. */
        panel.add(bRojo);
        panel.add(bVerde);
        panel.add(bAzul);
        
        /* Insertar el panel en el ContentPane. */
        this.getContentPane().add(panel);
        
        /* Insertar la barra de herramientas en la ventana. */
        this.setJMenuBar(barraMenu);
        
        /* Una clase anónima interna para cerrar la aplicación cuando se cierre
        la ventana. */
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
    } // Fin del constructor.
    
    /* Clases internas para los escuchadores que se asocian a dos fuentes de
    evento. */
    public class EscuchadorRojo implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            panel.setBackground(Color.RED);
        }
        
    } // Fin de la clase interna EscuchadorRojo.
    
    public class EscuchadorVerde implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            panel.setBackground(Color.GREEN);
        }
        
    } // Fin de la clase EscuchadorVerde.
    
    public class EscuchadorAzul implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            panel.setBackground(Color.BLUE);
        }
        
    } // Final de la clase Escuchador Azul
    
} // Fin de la clase.
