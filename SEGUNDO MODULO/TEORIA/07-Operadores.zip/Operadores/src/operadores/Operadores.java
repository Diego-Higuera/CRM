/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operadores;

/**
 *
 * @author mourelle
 */
public class Operadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Los operadores unarios actúan sobre un único operando. La posición
        es importante. Si prefijamos el operador al operando, primero se
        calcula su resultado y luego se utiliza en la expresión. Si el operador
        está postfijado, primero se ejecuta la expresión y luego el cálculo. */
        int i = 3;
        System.out.println(++i);
        
        int j = 10;
        System.out.println(j++);
        System.out.println(j);
        
        /* El operador de asignación = asigna el valor de una expresión a una
        variable. Primero se calcula el resultado de la expresión (a la derecha)
        y luego ese resultado se asigna a la variable. */
        int x = 2 * 3;
        /* El operador de asignación se puede combinar con otros operadores. */
        x += 2; // Sería equivalente a x = x + 2
        
        /* Los operadores aritméticos son la suma (+), la resta (-), la multi-
        plicación (*), la división (/) y el módulo o resto entero de una 
        división (%). */
        int resto = 17 % 3;
        System.out.println(resto);
        
        /* Los operadores de comparación son la igualdad (==), la desigualdad
        (!=), menor que (<), mayor que (>), menor o igual (<=) y mayor o igual
        (>=). */
        System.out.println( 7 > 3 );
        
        /* La concatenación consiste en unir dos cadenas de caracteres. Su
        operador es el signo más (+). Si uno de los operandos es String y el
        otro no, Java realiza una conversión implícita a cadena de este último
        y realiza la concatenación. */
        System.out.println("Siete se escribe así: " + 7);
        /* Pero ojo cuando queramos utilizar el operador + como concatenación y
        como suma en la misma expresión. */
        System.out.println("Suma de dos más dos: " + (2 + 2));
        
        /* Operadores lógicos. 
	p | q | !p | p & q | p | q | p ^ q |
       ---|---|----|-------|-------|-------|
        V | V |  F |   V   |   V   |   F   |
        V | F |  F |   F   |   V   |   V   |
        F | V |  V |   F   |   V   |   V   |
        F | F |  V |   F   |   F   |   F   |        
        */
        
        /* Recordad que para alterar el orden de evaluación de cualquier
        expresión, se pueden utilizar los paréntesis. */

    } // Final del método main().
    
} // Final de la clase.
