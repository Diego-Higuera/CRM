/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploborderlayout;

/**
 *
 * @author mourelle
 */
public class EjemploBorderLayout {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Pantalla ventana = new Pantalla();
        ventana.setVisible(true);

    } // Final del método main().
    
} // Final de la clase.
