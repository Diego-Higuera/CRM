/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploborderlayout;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
        
        /* Configuraciones. */
        this.setTitle("BorderLayout");
        this.setSize(500, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /* Panel principal. */
        JPanel panelPpal = new JPanel();
        /* Recordad que JPanel tiene por defecto el renderizador FlowLayot.
        Para asignarle BorderLayout. */
        BorderLayout bl = new BorderLayout();
        panelPpal.setLayout(bl);
        ((BorderLayout)panelPpal.getLayout()).setHgap(20);
        ((BorderLayout)panelPpal.getLayout()).setVgap(20);
        
        /* Panel norte. */
        JPanel panelNorte = new JPanel();
        panelNorte.setBackground(Color.BLUE);
        /* Añadimos al principal el panel norte. */
        panelPpal.add(panelNorte,BorderLayout.NORTH);
        
        /* Panel oeste. */
        JPanel panelOeste = new JPanel();
        panelOeste.setBackground(Color.GREEN);
        panelPpal.add(panelOeste,BorderLayout.WEST);
        
        /* Panel centro. */
        JPanel panelCentro = new JPanel();
        panelCentro.setBackground(Color.MAGENTA);
        panelPpal.add(panelCentro,BorderLayout.CENTER);
        
        /* Panel este. */
        JPanel panelEste = new JPanel();
        panelEste.setBackground(Color.ORANGE);
        panelPpal.add(panelEste,BorderLayout.EAST);
        
        /* Panel sur. */
        JPanel panelSur = new JPanel();
        panelSur.setBackground(Color.PINK);
        panelPpal.add(panelSur,BorderLayout.SOUTH);
        
        /* Añadir el panel principal al ContentPane. */
        this.getContentPane().add(panelPpal);
        
    } // Final del constructor.
    
} // Final de la clase.
