/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joptionpanejava;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class JOptionPaneJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* JOptionPane nos proporciona cuadros de diálogo para mostrar mensajes
        al usuario, para recabar datos, etc.
        */
        
        /* Mostrar un mensaje al usuario. */
        JOptionPane.showMessageDialog(
                null, 
                "Tengo una muñeca vestida de azul...", 
                "Canción chorra", 
                JOptionPane.INFORMATION_MESSAGE);

        /* Cuadro de diálogo para solicitar y recuperar un valor del usuario. */
        int edad = Integer.parseInt(JOptionPane.showInputDialog(
                null, 
                "Escribe tu edad", 
                "Edad", 
                JOptionPane.QUESTION_MESSAGE));
        JOptionPane.showMessageDialog(
                null, 
                "Confirmación de tu edad: " + edad, 
                "Confirmación", 
                JOptionPane.INFORMATION_MESSAGE);

        /* También cuadros de diálogo para elegir una opción. */
        Object color = JOptionPane.showInputDialog(
                null, 
                "Selecciona un color", 
                "Colores", 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                new Object[] {"Amarillo","Rojo","Verde","Azul","Naranja"}, 
                "Amarillo");
        JOptionPane.showMessageDialog(
                null, 
                "Tu color es: " + color,
                "Colores", 
                JOptionPane.INFORMATION_MESSAGE);

        /* Cuadros de diálogo para confirmación. */
        int respuesta = JOptionPane.showConfirmDialog(
                null, 
                "¿Quieres formatear tu ordenador? ", 
                "Formatear", 
                JOptionPane.YES_NO_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE);

        switch ( respuesta ) {
            case JOptionPane.YES_OPTION:
                JOptionPane.showMessageDialog(null, "Formateando tu ordenador");
                break;
            case JOptionPane.NO_OPTION:
                 JOptionPane.showMessageDialog(null, 
                         "No quieres dejar de formatear tu ordenador. "
                                 + "Formateando...");
                break;
            case JOptionPane.CANCEL_OPTION:
                JOptionPane.showMessageDialog(null, 
                        "No se puede cancelar el formateo. Formateando...");
                break;
       } // Final del switch.

    } // Final del método main().
    
} // Final de la clase.
