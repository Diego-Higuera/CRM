/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosventanas;

/**
 *
 * @author mourelle
 */
public class DosVentanas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        VentanaPrincipal principal = new VentanaPrincipal();
        VentanaSecundaria secundaria = new VentanaSecundaria();
        
        /* Una vez creadas ambas ventanas informo a ventana principal de la
        existencia de la ventana secundaria. */
        principal.setVentanaSecundaria(secundaria);
        /* Y a la ventana secundaria, le informo de cuál es su principal. */
        secundaria.setVentanaPrincipal(principal);


        principal.setVisible(true);



    } // Final del método main().
    
} // Final de la clase.
