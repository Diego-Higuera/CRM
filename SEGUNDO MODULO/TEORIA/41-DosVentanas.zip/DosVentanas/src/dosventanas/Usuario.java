/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosventanas;

/**
 *
 * @author mourelle
 */
public final class Usuario {
    
    /* Atributos. */
    private final String nombre;
    private final String apellido;
    private final String telefono;
    
    /* Constructor por defecto. */
    public Usuario(){
        nombre = "";
        apellido = "";
        telefono = "";
    }
    
    /* Constructor sobrecargado. */
    public Usuario( String nombre, String apellido, String telefono ) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
    }
    
    /* Accesores. */
    public String getNombre() {
        return nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public String getTelefono() {
        return telefono;
    }

    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = "Nombre: " + nombre + "\n";
        resultado += "Apellido: " + apellido + "\n";
        resultado += "Teléfono: " + telefono;
        
        return resultado;
    }
    
} // Final de la clase.
