/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosventanas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public final class VentanaSecundaria extends JFrame {
    
    /* Atributos. */
    private VentanaPrincipal ventanaPrincipal;
    private Usuario usuario;
    private JLabel lblNombre, lblApellido, lblTelefono;
    
    public VentanaSecundaria() {
        
        this.setTitle("Secundaria");
        this.setSize(240,170);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new FlowLayout(FlowLayout.LEFT,20,5));
        
        lblNombre = new JLabel("Nombre:");
        lblNombre.setPreferredSize(new Dimension(200,24));
        panelCentro.add(lblNombre);
        lblApellido = new JLabel("Apellido:");
        lblApellido.setPreferredSize(new Dimension(200,24));
        panelCentro.add(lblApellido);
        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setPreferredSize(new Dimension(200,24));
        panelCentro.add(lblTelefono);
        
        panel.add(panelCentro,BorderLayout.CENTER);
        
        JPanel panelSur = new JPanel();
        /* Con el renderizador por defecto FlowLayout centrado. */
        
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        });
        panelSur.add(btnCerrar);
        
        panel.add(panelSur,BorderLayout.SOUTH);
        
        /* Añadir el panel principal al ContentPane. */
        this.getContentPane().add(panel);
        
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cerrarVentana();
            }
        });
        
    } // Final del constructor.
    
    /* Accesores. */
    public VentanaPrincipal getVentanaPrincipal() {
        return ventanaPrincipal;
    }
    public void setVentanaPrincipal( VentanaPrincipal ventanaPrincipal ) {
        this.ventanaPrincipal = ventanaPrincipal;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario( Usuario usuario ) {
        this.usuario = usuario;
    }
    
    /* En el constructor no podemos volcar los datos del usuario, dado que
    todavía no existe. No existirá hasta que ventana principal los vuelque
    en ventana secundaria. Necesitaremos entonces un método para pintar los
    datos del usuario. */
    public void pintarUsuario() {
        lblNombre.setText("Nombre: " + usuario.getNombre());
        lblApellido.setText("Apellido: " + usuario.getApellido());
        lblTelefono.setText("Teléfono: " + usuario.getTelefono());
    }
    
    /* Método para cerrar la ventana. */
    private void cerrarVentana() {
        /* Ocultar la ventana secundaria. */
        this.setVisible(false);
        
        /* Mostrar la ventana principal. */
        ventanaPrincipal.setVisible(true);
    }
    
} // Final de la clase.
