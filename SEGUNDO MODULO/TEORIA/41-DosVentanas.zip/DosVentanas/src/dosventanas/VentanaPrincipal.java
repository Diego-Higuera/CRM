/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dosventanas;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mourelle
 */
public final class VentanaPrincipal extends JFrame {
    
    /* Permitir que ventana principal conozca de la existencia de la ventana
    secundaria. */
    private VentanaSecundaria ventanaSecundaria;
    
    public VentanaPrincipal() {

        /* Configuraciones generales. */
        this.setTitle("Principal");
        this.setSize(240, 270);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Panel principal. */
        JPanel panel = new JPanel();
        /* Renderizador BorderLayout. */
        panel.setLayout(new BorderLayout());
        
        JPanel panelCentral = new JPanel();
        ((FlowLayout)panelCentral.getLayout()).setAlignment(FlowLayout.LEFT);
        ((FlowLayout)panelCentral.getLayout()).setHgap(20);
        ((FlowLayout)panelCentral.getLayout()).setVgap(5);
        JLabel lblNombre = new JLabel("Nombre");
        lblNombre.setPreferredSize(new Dimension(190,24));
        panelCentral.add(lblNombre);
        JTextField txtNombre = new JTextField();
        txtNombre.setPreferredSize(new Dimension(190,24));
        panelCentral.add(txtNombre);
        JLabel lblApellido = new JLabel("Apellido");
        lblApellido.setPreferredSize(new Dimension(190,24));
        panelCentral.add(lblApellido);
        JTextField txtApellido = new JTextField();
        txtApellido.setPreferredSize(new Dimension(190,24));
        panelCentral.add(txtApellido);
        JLabel lblTelefono = new JLabel("Teléfono");
        lblTelefono.setPreferredSize(new Dimension(190,24));
        panelCentral.add(lblTelefono);
        JTextField txtTelefono = new JTextField();
        txtTelefono.setPreferredSize(new Dimension(190,24));
        panelCentral.add(txtTelefono);
        panel.add(panelCentral, BorderLayout.CENTER);
        
        JPanel panelSur = new JPanel();
        /* Ya tiene el renderizador adecuado FlowLayout centrado. */
        JButton btnEnviar = new JButton("Enviar");
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Recopilar la información de la ventana y guardarla en un
                objeto de tipo Usuario. */
                String nombre = txtNombre.getText();
                String apellido = txtApellido.getText();
                String telefono = txtTelefono.getText();
                Usuario usuario = new Usuario(nombre, apellido, telefono);
                
                /* Ya puedo borrar los cuadros de texto. */
                txtNombre.setText("");
                txtApellido.setText("");
                txtTelefono.setText("");
                
                /* Enviar el usuario a la ventana secundaria. */
                ventanaSecundaria.setUsuario(usuario);
                
                /* Ocultar la ventana principal. */
                setVisible(false);
                
                /* Mostrar la ventana secundaria. */
                ventanaSecundaria.pintarUsuario();
                ventanaSecundaria.setVisible(true);
            }
        });
        panelSur.add(btnEnviar);
        JButton btnSalir = new JButton("Salir");
        /* Escuchador para cerrar la aplicación. */
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarAplicacion();
            }
        });
        panelSur.add(btnSalir);
        panel.add(panelSur,BorderLayout.SOUTH);
        
        /* Asociar el panel principal al ContentPane. */
        this.getContentPane().add(panel);
        
        /* Salir de la aplicación cuando se pulse el botón de cerrado (x) de la
        ventana. */
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cerrarAplicacion();
            }
        });
        
    } // Final del constructor.
    
    /* Accesores. */
    public VentanaSecundaria getVentanaSecundaria() {
        return ventanaSecundaria;
    }
    public void setVentanaSecundaria( VentanaSecundaria ventanaSecundaria ) {
        this.ventanaSecundaria = ventanaSecundaria;
    }
    
    private void cerrarAplicacion() {
        /* Preguntar al usuario si realmente quiere cerrar la aplicación. */
        int respuesta = JOptionPane.showConfirmDialog(
                null, 
                "¿Está seguro que desea salir de la aplicación?", 
                "Salir de la aplicación", 
                JOptionPane.YES_NO_OPTION, 
                JOptionPane.QUESTION_MESSAGE);

        if ( respuesta == JOptionPane.OK_OPTION ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Muchas gracias por utilizar esta aplicación. Hasta pronto.", 
                    "Salir de la aplicación", 
                    JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    } // Final del método cerrarAplicacion().
    
} // Final de la clase.
