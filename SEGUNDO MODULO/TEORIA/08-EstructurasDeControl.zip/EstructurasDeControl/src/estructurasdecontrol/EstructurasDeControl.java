/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estructurasdecontrol;

/**
 *
 * @author mourelle
 */
public class EstructurasDeControl {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Condicional simple. Se analiza una condición y sólo si es verdadera
        se ejecuta el código. Si el falsa, continúa sin hacer nada. */
        int edad = 18;
        if ( edad >= 18 ) {
            // Acciones a ejecutar si la condición es verdadera.
            System.out.println("Puedes acceder al sistema");
        }
        
        /* Condicional doble. Se ejecuta un conjunto de acciones si la condición
        es verdadera y otro si es falsa. */
        if ( edad >= 18 ) {
            // Acciones si la condición es verdadera.
            System.out.println("Puedes votar");
        } else {
            // Acciones si la condición es falsa.
            System.out.println("No puedes votar");
        }
        
        /* Condicional múltiple. Permite analizar varias condiciones y ejecutar
        unas acciones u otras dependiendo del resultado. */
        if ( edad>= 18 ) {
            // Acciones para la condición1 verdadera
            System.out.println("Eres adulto");
        } else if ( edad >= 13 ) {
            // Acciones cuando condición1 es falsa y condición2 verdadera
            System.out.println("Eres adolescente");
        } else if ( edad >= 5 ) {
            // Acciones en caso de que condición1 y condición 2 sean falsas,
            // pero condición3 es verdadera.
            System.out.println("Eres un niño");
        } else {
            // Acciones si condición1, condición2 y condición3 son falsas.
            System.out.println("Eres un bebé");
        }
        
        /* La estructura switch permite evaluar varias condiciones de una forma
        más legible. Básicamente, compara una variable con distintos valores y
        ejecuta una serie de acciones según el valor de dicha variable. */
        int nota = 7;
        switch( nota ) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                System.out.println("Suspenso");
                break;
            case 5:
                System.out.println("Aprobado");
                break;
            case 6:
                System.out.println("Bien");
                break;
            case 7:
            case 8:
                System.out.println("Notable");
                break;
            case 9:
            case 10:
                System.out.println("Sobresaliente");
                break;
            default:
                System.out.println("La nota no está dentro del rango.");
        } // Final del switch.
        
        /* Los bucles nos permiten repetir varias veces un bloque de código.
        Es imprescindible utilizar el bucle correcto en cada situación. En el
        bucle while, la condición se evalúa al principio, de manera que si en
        ese momento es false, el código no llegará a ejecutarse. */
        int i = 10;
        while ( i > 0 ) {
            /* El código se ejecuta mientras la condición es true. */
            System.out.println(i);
            /* Debemos variar la condición, dado que si no, nos metemos en un
            bucle infinito. La variación debe ser tal que vayamos convergiendo
            hacia el final del bucle. */
            i--;
        }
        
        /* La estructura do...while se diferencia en que esta vez el bloque de
        código se ejecuta al menos una vez. La condición se evalúa al final y
        el bucle se sigue ejecutando mientras dicha condición sea verdadera. */
        do {
            System.out.println(i);
            /* Seguimos teniendo que variar la condición. */
            i++;
        } while( i <= 10 ); // No olvidéis el punto y coma
        
        System.out.println("Ahora i vale " + i);
        
        /* El bucle for se utiliza cuando conocemos exactamente el número de
        iteraciones. La sintaxis incluye tres elementos: la inicialización de
        una variable de control, la condición que se debe cumplir para seguir
        ejecutando el bucle y una variación de la variable de control para que
        ésta converja hacia la condición. */
        for ( int j=0; j<=10; j++ ) {
            System.out.println(j);
        }
        
    } // Final del método main().
    
} // Final de la clase.
