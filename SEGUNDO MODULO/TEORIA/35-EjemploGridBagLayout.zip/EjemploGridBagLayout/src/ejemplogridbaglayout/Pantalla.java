/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplogridbaglayout;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
        
        this.setTitle("GridBagLayout");
        this.setSize(500,500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /* Panel principal. */
        JPanel panel = new JPanel();
        GridBagLayout gbl = new GridBagLayout();
        panel.setLayout(gbl);
        
        JButton b1 = new JButton("Botón 1");
        /* GridBagConstraints para especificar las características del botón
        dentro de la cuadrícula del panel. */
        GridBagConstraints gbc = new GridBagConstraints();
        /* Posición del componente. Empieza por cero. */
        gbc.gridx = 0;
        gbc.gridy = 0;
        /* Cuántas filas y columnas ocupa. */
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        /* Cómo se comporta el elemento cuando redimensionamos la ventana. */
        gbc.weightx = 100;
        gbc.weighty = 100;
        /* Qué pasa si el componente no ocupa todo el espacio. */
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        /* Sólo queda añadir el botón al panel especificando cuál es su gbc que
        contiene las especificaciones del control. */
        panel.add(b1,gbc);
        
        /* Segundo botón, a la derecha del primero y ocupando solamente una
        columna. Podríamos definir un nuevo gbc o reutilizar el que ya tenemos
        cambiando solo las características necesarias. */
        JButton b2 = new JButton("Botón 2");
        /* Su posición x es 2, ya que el primer botón, ocupa dos columnas. Su
        posición y se mantiene. */
        gbc.gridx = 2;
        /* Para hacer que ocupe una sola columna, tenemos que modificar el valor
        de gridwidth. */
        gbc.gridwidth = 1;
        /* El resto lo mantenemos, salvo el anchor para jugar un poco. */
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        panel.add(b2,gbc);
        
        /* El botón 3 se sitúa en la segunda fila (y=1), ocupa tres columnas y
        el botón se adapta al tamaño de la cuadrícula. */
        JButton b3 = new JButton("Botón 3");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        panel.add(b3,gbc);
        
        /* El botón 4 se coloca en la tercera fila, ocupa sólo una columna y
        vamos a colocarlo centrado en la cuadrícula. */
        JButton b4 = new JButton("Botón 4");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(b4,gbc);
        
        /* El botón 5 se ubica en la columa 1 (la segunda), tercera fila, con
        un ancho de dos cuadrículas y una ubicación suroeste. */
        JButton b5 = new JButton("Botón 5");
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.SOUTHWEST;
        panel.add(b5,gbc);
        
        /* Añado el panel al ContentPane. */
        this.getContentPane().add(panel);
        
    } // Final del constructor.
    
} // Final de la clase.
