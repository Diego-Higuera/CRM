/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploenumerado;

import javax.swing.JOptionPane;

/**
 *
 * @author FormadorM
 */
// En principo, una clase enum puede considerarse como otra clase cualquiera
// en la que tenemos la posibilidad de definir distintas constantes y
// asignarles uno o varios valores a dichas constantes.
public enum Hamburguesas {
    // Estas son las constantes. Obsérvese que en realidad son una especie
    // de llamadas al constructor que veremos más adelante. Cada nueva
    // constante define el peso de la hamburguesa y su precio
    XS(200,1.0),
    MEDIUM(250,1.5),
    LARGE(400,2.5);
    
    // Como hemos visto, las hamburguesas manejan dos atributos: peso y precio
    private final int peso;
    private final double precio;

    // Este es un constructor del enumerado Hamburguesas. Habitualmente solemos
    // verlo con visibilidad omitida (como protected), aunque sería válido
    // también darle una visibilidad privada. Al fin y al cabo, este
    // constructor es sólo para crear los tipos de hamburguesas dentro del
    // enum. Los tipos enumerados no pueden ser instanciados desde fuera
    private Hamburguesas(int peso, double precio){
        this.peso = peso;
        this.precio = precio;
    }

    // Los accesores son sólo los get. Téngase en cuenta, que los atributos
    // deben ser finales, no pueden cambiar. Ya sabemos que las constantes
    // no pueden cambiar de valor. Estos métodos nos permitirán saber
    // los valores que tiene cualquiera de nuestros tipos enumerados
    public int getPeso() {
        return peso;
    }

    public double getPrecio() {
        return precio;
    }
    
    public void mostrar(){
        JOptionPane.showMessageDialog(
                null,
                "Tipo: " + this.toString() + "\n" +
                "Peso: " + this.getPeso() + " gramos\n" +
                "Precio: " +  this.getPrecio() + " euros\n", 
                "Su hamburguesa...", JOptionPane.INFORMATION_MESSAGE);
        
    }
}
