/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploenumerado;

import javax.swing.JOptionPane;

/**
 *
 * @author FormadorM
 */
public class EjemploEnumerado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Practiquemos el uso de las constantes del enumerado
        // En cualquier momento, puedo utilizar estas constantes haciendo
        // referencia al nombre de su "clase" o tipo enumerado
        System.out.println(Hamburguesas.LARGE.getPeso());
        System.out.println(Hamburguesas.MEDIUM.toString());
        
        // Declaramos un objeto de tipo Hamburguesas que en el momento de su
        // declaración tiene el valor null
        Hamburguesas suHamburguesa;
        
        suHamburguesa = Hamburguesas.valueOf(
            (String) JOptionPane.showInputDialog(
                            null,   // Ventana padre
                            "Seleccione una hamburguesa", // Mensaje
                            "Selección",    // Título de la ventana
                            JOptionPane.QUESTION_MESSAGE, // Tipo de icono
                            null, // Icono de sustitución
                            new Object[]{Hamburguesas.XS.toString(),
                                Hamburguesas.MEDIUM.toString(),
                                Hamburguesas.LARGE.toString() }, 
                            Hamburguesas.MEDIUM.toString())        
        );
        
        suHamburguesa.mostrar();
        
    } // Fin del main
    
} // Fin de la clase
