/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplogridlayout;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla(){

        this.setTitle("GridLayout");
        this.setSize(300,400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        /* Panel principal. */
        JPanel panel = new JPanel();
        // GridLayout gl = new GridLayout(2,2);
        /* Si queremos que el crecimiento sea en filas cuando inserto más
        elementos de los que permite la cuadrícula, tengo que especificar el
        valor 0 para el número de filas. */
        GridLayout gl = new GridLayout(0,2);
        panel.setLayout(gl);

        JButton b1, b2, b3, b4, b5, b6;
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        /* Si me paso de revoluciones e inserto más botones de los que admite
        la cuadrícula, GridLayout lo solucionará añadiendo más columnas. */
        b5 = new JButton("5");
        b6 = new JButton("6");
        

        /* Vuelco los botones al panel. */
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b4);
        panel.add(b5);
        panel.add(b6);

        /* Vuelco el panel en el ContentPane. */
        this.getContentPane().add(panel);
        
    } // Final del constructor.
    
} // Fin de la clase.
