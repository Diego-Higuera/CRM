/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraysjava;

import java.util.Arrays;

/**
 *
 * @author mourelle
 */
public class ArraysJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Para declarar un array lo hacemos igual que una variable normal
        pero añadimos una pareja de corchetes ([]) a continuación del tipo de
        datos. */
        int[] cifraNegocio;
        
        /* Después creamos el array (reservar memoria para su almacenamiento).
        En este momento indicamos el tamaño del array. Utilizaremos el operador
        new para crear una instancia del array. */
        cifraNegocio = new int[12];
        
        /* También podemos declarar, crear e inicializar el array simultánea-
        mente con la siguiente estructura. */
        int[] cifraNegocio2 = {123,456,789,12,543,777,431,167,776,263,987,435};
        
        /* Acceso a los elementos de un array. */
        cifraNegocio[0] = 12456;
        System.out.println(cifraNegocio[0]);
        
        /* Cuando manipulamos un array hay que procurar no intentar acceder a
        un índice inexistente. Se producirá un error en tiempo de ejecución de
        tipo ArrayIndexOutOfBoundsException. */
        // cifraNegocio[12] = 876;
        
        /* Un array de varias dimensiones no es más que un array normal cuyos
        valores son otros arrays en lugar de datos normales. En la declaración
        del array se deben escribir tantos pares de corechetes como dimensiones
        deseemos crear. */
        int[][] matriz;
        
        /* Luego, establemos el tamaño de cada dimensión. */
        matriz = new int[2][3];
        
        /* Manipulación del array de dos dimensiones. */
        matriz[0][0] = 123;
        matriz[0][1] = 234;
        matriz[0][2] = 345;
        
        /* La declaración, creación e inicialización simultánea del array tendrá
        el siguiente aspecto: */
        int[][] matriz2 = {
            {11,22,33},
            {21,22,23}
        };
        System.out.println(matriz2[1][1]);
        
        /* Las principales manipulaciones de los arrays podemos realizarlas
        gracias a la clase java.util.Arrays. Proporciona métodos estáticos para
        la manipulación de arrays. */
        
        /* Obtener el tamaño de un array. Para ello disponemos de la propiedad
        length. */
        int[][] matriz3 = new int[8][3];
        int filas = matriz3.length;
        int columnas = matriz3[0].length;
        System.out.println("El array tiene " + filas + " filas por " + 
                columnas + " columnas.");
        
        /* Para realizar búsquedas en un array, utilizaremos el método 
        binarySearch de la clase Arrays. Devolverá el índice del array donde
        se encontró el valor o un valor negativo en caso de no encontrarlo.
        Para que este método funcione de forma óptima hay que ordenar antes el
        array. La ordenación es alfabética para arrays de texto y ascendente
        para valores numéricos. */
        Arrays.sort(cifraNegocio2);
        /* Buscamos el valor 123 en el array. En el método especificamos el
        nombre del array donde queremos hacer la búsqueda y el valor a buscar.
        */
        int posicion = Arrays.binarySearch(cifraNegocio2, 123);
        System.out.println("El valor 123 se encuentra en la posición " + 
                posicion);
        
        /* Para mostrar los contenidos de un array, utilizamos el método
        toString() de la clase Arrays. */
        System.out.println(Arrays.toString(cifraNegocio2));
        
        /* Si se trata de un array de dos dimensiones, usamos el método
        deepToString(). */
        System.out.println(Arrays.deepToString(matriz2));
        
        /* Para rellenar un array con un valor determinado, utilizamos el método
        fill de la clase Arrays. Debemos especificar como primer argumento el
        nombre de la matriz y como segundo el valor a asignar. */
        Arrays.fill(cifraNegocio, 7);
        System.out.println(Arrays.toString(cifraNegocio));
        
    } // Final del método main.
    
} // Final de la clase.
