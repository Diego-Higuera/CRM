/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploflowlayout;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Ventana1 extends JFrame {
    
    public Ventana1() {
        
        /* Configuraciones. */
        this.setTitle("Ventana 1");
        this.setBounds(0, 0, 400, 300);
        /* No vamos a controlar por nuestra cuenta el cierre de la 
        aplicación. */
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /* Creamos varios botones. */
        JButton b1, b2, b3, b4, b5;
        b1 = new JButton("Botón 1");
        b2 = new JButton("Botón 2");
        b3 = new JButton("Botón 3");
        b4 = new JButton("Botón 4");
        b5 = new JButton("Botón 5");
        
        /* Creamos el panel intermedio. */
        JPanel panel = new JPanel();
        
        /* Puedo cambiar el renderizador por defecto del panel. */
        FlowLayout fl = new FlowLayout(FlowLayout.LEFT,10,20);
        panel.setLayout(fl);
        
        /* Añadimos los botones al panel. */
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b4);
        panel.add(b5);
        
        /* Añadimos el panel al ContentPane. */
        this.getContentPane().add(panel);
        
    } // Final del constructor.
    
} // Final de la clase.
