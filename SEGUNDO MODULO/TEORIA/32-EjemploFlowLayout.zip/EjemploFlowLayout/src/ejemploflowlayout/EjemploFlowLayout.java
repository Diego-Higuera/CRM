/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploflowlayout;

/**
 *
 * @author mourelle
 */
public class EjemploFlowLayout {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Creo una Ventana1. */
        Ventana1 v1 = new Ventana1();
        v1.setVisible(true);
        
        /* Una Ventana2. */
        Ventana2 v2 = new Ventana2();
        v2.setVisible(true);

    } // Fin del método main().
    
} // Fin de la clase.
