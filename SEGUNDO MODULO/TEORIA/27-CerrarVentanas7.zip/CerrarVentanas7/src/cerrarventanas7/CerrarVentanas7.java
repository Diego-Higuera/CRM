/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cerrarventanas7;

/**
 *
 * @author mourelle
 */
public class CerrarVentanas7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Instanciamos una ventana de tipo Pantalla. */
        Pantalla ventana = new Pantalla();
        
        /* No olvidemos mostrar la ventana. */
        ventana.setVisible(true);
        
    } // Fin del método main().
    
} // Fin de la clase.
