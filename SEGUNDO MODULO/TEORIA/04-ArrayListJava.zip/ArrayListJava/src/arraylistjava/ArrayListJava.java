/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistjava;

/* Importamos la clase ArrayList. */
import java.util.ArrayList;

/**
 *
 * @author mourelle
 */
public class ArrayListJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Declaración y creación de un ArrayList de cadenas. */
        ArrayList<String> nombres = new ArrayList<>();
        
        /* Agregar elementos a un ArrayList. Utilizamos el método add(). Tenemos
        dos formatos. El primero añade el elemento al final del ArrayList. */
        nombres.add("Juan");
        nombres.add("Diego");
        
        /* La segunda forma, permite definir la posición donde queremos añadir
        el nuevo elemento. En caso de que dicha posición ya esté ocupada, se
        desplazan todos los elementos hacia el final. Primero especificamos la
        posición y luego el valor a añadir. */
        nombres.add(0,"Manuel");
        
        /* El método get() nos permite obtener el valor que hay en una posición
        del ArrayList. */
        System.out.println(nombres.get(1));
        
        /* Si queremos sustituir el dato que hay en una posición determinada del
        ArrayList, usamos el método set(), especificando la posición a sustituir
        y el nuevo valor. */
        nombres.set(0,"Patricia");
        System.out.println(nombres.get(0));
        
        /* Tamaño de un ArrayList. Usamos el método size(). */
        System.out.println("El tamaño del ArrayList es: " + 
                nombres.size());
        
        /* Contains devuelve verdadero o falso según si el valor que se indica
        como argumento se encuentra o no en el ArrayList. */
        System.out.println(nombres.contains("Manuel"));
        
        /* Podemos buscar la posición en la que se encuentra un valor determi-
        nado en el ArrayList. Devolverá -1 si no encuentra el valor. */
        int posicion = nombres.indexOf("Juan");
        System.out.println("Juan está en la posición " + posicion);
        
        /* Igual que en los arrays, toString() muestra el contenido de un
        ArrayList. */
        System.out.println(nombres.toString());
        
        /* Eliminar un elemento del ArrayList. Método remove(). */
        nombres.remove("Diego");
        System.out.println(nombres.toString());
        
    } // Final del método main().
    
} // Final de la clase.
