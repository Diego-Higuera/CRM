/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unescuchadorparatodos;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    /* Hacemos el panel global a toda la clase Pantalla. */
    JPanel panel;
    /* También globales los botones y los elementos de menú. */
    JButton bRojo, bVerde, bAzul;
    JMenuItem menuRojo, menuVerde, menuAzul;
    
    /* Constructor. */
    public Pantalla() {
        
        /* Configuraciones. */
        this.setTitle("Colores");
        this.setSize(300,100);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Componentes de la ventana. */
        
        /* Botones. */
        bRojo = new JButton("Rojo");
        bVerde = new JButton("Verde");
        bAzul = new JButton("Azul");

        /* Un único escuchador me servirá para todos los botones y para todos
        los menús. */
        EscuchadorColor ec = new EscuchadorColor();
        bRojo.addActionListener(ec);
        bVerde.addActionListener(ec);
        bAzul.addActionListener(ec);
        
        /* Creamos el menú. */
        
        /* Barra de menús. */
        JMenuBar barraMenu = new JMenuBar();
        /* Menú para los colores. */
        JMenu menuColores = new JMenu("Colores");
        /* Elementos del menú. */
        menuRojo = new JMenuItem("Rojo");
        menuVerde = new JMenuItem("Verde");
        menuAzul = new JMenuItem("Azul");
        
        /* El escuchador de color que ya tenemos podemos asociarlo a todos los
        elementos de menú. */
        menuRojo.addActionListener(ec);
        menuVerde.addActionListener(ec);
        menuAzul.addActionListener(ec);
        
        /* Introducimos los elementos de menú en el menú. */
        menuColores.add(menuRojo);
        menuColores.add(menuVerde);
        menuColores.add(menuAzul);
        /* Introducimos el menú en la barra. */
        barraMenu.add(menuColores);
        
        /* Panel intermedio. */
        panel = new JPanel();
        
        /* Insertar los botones en el panel. */
        panel.add(bRojo);
        panel.add(bVerde);
        panel.add(bAzul);
        
        /* Insertar el panel en el ContentPane. */
        this.getContentPane().add(panel);
        
        /* Insertar la barra de herramientas en la ventana. */
        this.setJMenuBar(barraMenu);
        
        /* Una clase anónima interna para cerrar la aplicación cuando se cierre
        la ventana. */
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
    } // Fin del constructor.

    /* Escuchador para todos los colores. */
    public class EscuchadorColor implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            
            /* Vamos a aprovechar el objeto ActionEvent para, a través de su
            método getSource(), reconocer la fuente de evento sobre la que se
            ha hecho clic. */
            if ( e.getSource()==bRojo | e.getSource()==menuRojo ) {
                panel.setBackground(Color.RED);
            }
            if ( e.getSource()==bVerde | e.getSource()==menuVerde) {
                panel.setBackground(Color.GREEN);
            }
            if ( e.getSource()==bAzul | e.getSource()==menuAzul) {
                panel.setBackground(Color.BLUE);
            }
            
        } // Final del actionPerformed().
        
    } // Final de la clase EscuchadorColor.
    
} // Fin de la clase Pantalla.
