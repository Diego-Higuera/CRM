/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author mourelle
 */
public class Clases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Mostramos cuántas personas hay en este momento en la aplicación. */
        System.out.println("Personas: " + Persona.numeroPersonas);
        
        
        /* Ejemplo de instanciación de objetos. */
        Persona beatriz;
        beatriz = new Persona();
        
        /* Probar el método de visualización. */
        beatriz.visualizacion("rojo","verde","azul");
        beatriz.visualizacion(null);
        
        /* Con los accesores podemos dar valores a todos los atributos del
        objeto. */
        beatriz.setNombre("BEATRIZ");
        beatriz.setApellido("fernández");
        beatriz.setFechaNaci(LocalDate.of(2006, Month.MARCH, 26));
        System.out.println(beatriz.getNombre());
        System.out.println(beatriz.getApellido());
        /* Recordemos los métodos de visualización. */
        beatriz.visualizacion(false);
        
        /* Creamos un nuevo objeto, esta vez con los constructores. */
        Persona edwin = new Persona("CaNtOr","EdWiN",LocalDate.of(1994, 2, 27));
        edwin.visualizacion();
        
        /* Como todas las clases heredan de Object, disponen de un método
        toString() por defecto, que convierte la información del objeto en una
        cadena de caracteres. */
        System.out.println(edwin.toString());
        
        /* Personas después de crear a Beatriz y Edwin: */
        System.out.println("Personas: " + Persona.numeroPersonas);
        
        /* Creamos un nuevo cliente. */
        Cliente cliente1 = new Cliente();
        cliente1.setNombre("ReBeCa");
        cliente1.setApellido("FeRmÍn");
        cliente1.setFechaNaci(LocalDate.of(2000, 7, 9));
        cliente1.setTipo('P');
        cliente1.visualizacion();
        
        
    } // Final del método main().
    
} // Final de la clase.
