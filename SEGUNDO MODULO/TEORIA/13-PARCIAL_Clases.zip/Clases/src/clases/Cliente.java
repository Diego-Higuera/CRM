/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.time.LocalDate;

/**
 *
 * @author mourelle
 */
public final class Cliente extends Persona {
    
    /* Atributos. */
    /* Tipo de cliente, de acuerdo a la siguiente terminaología: 
        P -> particular
        E -> empresa
        A -> administración
    */
    private char tipo;
    
    /* Pero al heredar de Persona, esta clase también dispone de los atributos
    de la clase base. */
    
    
    /* Constructores. */
    
    /* Constructor predeterminado. */
    public Cliente() {
        /* Inicializar los atributos comunes con la clase base Persona. */
        super();
        /* Inicializar el tipo de cliente. */
        tipo = '\u0000';
    }
    
    /* Constructor sobrecargado. */
    public Cliente( String apellido, String nombre, 
            LocalDate fechaNaci, char tipo) {
        super(apellido, nombre, fechaNaci);
        this.tipo = tipo;
    }
    
    
    /* Accesores (también dispone de los accesores del padre). */
    public char getTipo() {
        return tipo;
    }
    public void setTipo( char tipo ) {
        this.tipo = tipo;
    }




    /* Métodos específicos. */
    
    /* Sobrescribimos el método de visualización para que incluya también el
    tipo de cliente. */
    @Override
    public void visualizacion() {
        super.visualizacion();
        switch( tipo ) {
            case 'P':
                System.out.println("Tipo de cliente: Particular");
                break;
            case 'E':
                System.out.println("Tipo de cliente: Empresa");
                break;
            case 'A':
                System.out.println("Tipo de cliente: Administración");
                break;
            default:
                System.out.println("Tipo de cliente: Desconocido");
        }
    }

    
} // Fin de la clase Cliente.
