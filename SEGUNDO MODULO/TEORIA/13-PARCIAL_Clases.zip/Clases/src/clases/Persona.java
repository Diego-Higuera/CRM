/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author mourelle
 */

/* Esta clase podría y debería ser abstracta con la palabra clave abstract. 
Pero, como la hemos utilizado para hacer pruebas, no lo hacemos.*/
public class Persona {
    
    /* Atributos o campos de la clase. */
    private String apellido;
    private String nombre;
    private LocalDate fechaNaci;
    /* Añadimos un campo numero que asigna un número de orden a cada persona
    que se instancia en la aplicación. */
    private int numero;
    /* Un campo estático que llevará un contador de las personas que se
    instancien en la aplicación. Aunque en el libro pone este campo como 
    privado, si queremos acceder a él desde el exterior, tendrá que ser
    público. */
    public static int numeroPersonas;
    
    
    /* Constructores. */
    
    /* Por defecto. */
    public Persona() {
        apellido = "";
        nombre = "";
        fechaNaci = null;
        
        /* Asignación de número de orden y actualización del número de
        personas. */
        numeroPersonas++;
        numero = numeroPersonas;
    }
    
    /* Constructor sobrecargado. */
    public Persona(String apellido, String nombre, LocalDate fechaNaci) {
        /* ¡OJO! El constructor sobrecargado tiene que respetar también las
        reglas de negocio sobre los atributos de la clase. Los métodos set ya
        tienen esas reglas. Podemos utilizarlos aquí. */
        // this.apellido = apellido.toUpperCase();
        this.setApellido(apellido);
        // this.nombre = nombre.toLowerCase();
        this.setNombre(nombre);
        this.fechaNaci = fechaNaci;
        
        /* Asignación de número de orden y actualización del número de
        personas. */
        numeroPersonas++;
        numero = numeroPersonas;
    }
    
    
    /* Métodos accesores. */
    public String getApellido() {
        return apellido;
    }
    
    public void setApellido(String apellido) {
        this.apellido = apellido.toUpperCase();
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre.toLowerCase();
    }
    
    public LocalDate getFechaNaci() {
        return fechaNaci;
    }
    
    public void setFechaNaci(LocalDate fechaNaci) {
        this.fechaNaci = fechaNaci;
    }
    
    
    /* Sobrescribir el método toString() para proporcionar información sobre
    el objeto de una manera más útil para el programador. */
    @Override
    public String toString() {
        String resultado = "Nombre: " + nombre + "\n";
        resultado += "Apellido: " + apellido + "\n";
        resultado += "Edad: " + this.calculoEdad() + "\n";
        resultado += "Número: " + numero;
        
        return resultado;
    }
    
    
    /* Métodos personalizados. */
    
    /* Un método para calcular la edad de una persona. */
    public long calculoEdad() {
        return fechaNaci.until(LocalDate.now(), ChronoUnit.YEARS);
    }
    
    /* Un método para visualizar los campos del objeto. */
    public void visualizacion() {
        System.out.println("Apellido: " + apellido);
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + calculoEdad());
        System.out.println("Número: " + numero);
    }
    
    /* Método sobrecargado. */
    public void visualizacion(boolean español) {
        if ( español ) {
            System.out.println("Apellido: " + apellido);
            System.out.println("Nombre: " + nombre);
            System.out.println("Edad: " + calculoEdad());
            System.out.println("Número: " + numero);
        } else {
            System.out.println("Surname: " + apellido);
            System.out.println("First name: " + nombre);
            System.out.println("Age: " + calculoEdad());
            System.out.println("Number: " + numero);
        }
    }
    
    /* También es posible aceptar un número variable de parámetros. */
    public void visualizacion (String...colores) {
        /* Mostrar un mensaje según el número de colores enviados. */
        if ( colores == null ) {
            System.out.println("Ningún color");
            /* Podemos utilizar return en cualquier momento para detener la
            ejecución del método. */
            return;
        }
        
        switch ( colores.length ) {
            case 1:
                System.out.println("Un color");
                break;
            case 2:
                System.out.println("Dos colores");
                break;
            case 3:
                System.out.println("Tres colores");
                break;
            default:
                System.out.println("Más de tres colores");
        } // Final del switch.
        
    } // Final del método visualizacion (String...colores).
    
    
} // Final de la clase.
