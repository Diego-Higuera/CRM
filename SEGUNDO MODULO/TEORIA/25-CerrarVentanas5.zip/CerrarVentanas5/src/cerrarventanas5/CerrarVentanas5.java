/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cerrarventanas5;

/**
 *
 * @author mourelle
 */
public class CerrarVentanas5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Instanciamos una ventana de tipo Pantalla. */
        Pantalla ventana = new Pantalla();
        
        /* Creo una instancia del escuchador. */
        EscuchadorVentana ev = new EscuchadorVentana();
        /* Y lo asocio a la ventana. */
        ventana.addWindowListener(ev);
        
        /* No olvidemos mostrar la ventana. */
        ventana.setVisible(true);
        
    } // Fin del método main().
    
} // Fin de la clase.
