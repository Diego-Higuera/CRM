/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cerrarventanas5;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
/* En estos casos, podemos importar del tirón todas las clases de javax.swing
de la siguiente manera: */
// import javax.swing.*;

/**
 *
 * @author mourelle
 * 
 * La clase debe heredar de JFrame para disponer de todas las opciones de
 * configuración correspondientes.
 */
public class Pantalla extends JFrame{
    
    /* Hacemos un constructor con todas las opciones de configuración y todos
    los controles que necesite la ventana. */
    public Pantalla() {
        /* Configuración de la pantalla. */
        this.setTitle("Cerrar ventanas 6");
        this.setBounds(0, 0, 300, 100);
        /* Ahora, queremos controlar por nuestra cuenta lo que sucederá cuando
        se cierre la ventana (cerrar la aplicación). De esta manera, vamos a
        condigurar setDefaultCloseOperation para que no haga nada, ni siquiera
        cerrar la propia ventana. usaremos DO_NOTHING_ON_CLOSE. */
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        /* Construimos los tres botones. */
        JButton b1, b2, b3;
        b1 = new JButton("Rojo");
        b2 = new JButton("Verde");
        b3 = new JButton("Azul");
        
        /* Creo el panel intermedio. */
        JPanel panel = new JPanel();
        
        /* Añadimos los botones al panel. */
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        
        /* Añadimos el panel al ContentPane. */
        this.getContentPane().add(panel);
        
        /* Crear una instancia del escuchador de la clase interna. */
        EscuchadorVentana ev = new EscuchadorVentana();
        /* Asociarlo a this, que es esta ventana. */
        this.addWindowListener(ev);
        
    } // Final del constructor.
    
    /* Una clase interna que herede de WindowAdapter. */
    public class EscuchadorVentana extends WindowAdapter {
        
        @Override
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    } // Fin de la clase interna. 
    
} // Final de la clase.
