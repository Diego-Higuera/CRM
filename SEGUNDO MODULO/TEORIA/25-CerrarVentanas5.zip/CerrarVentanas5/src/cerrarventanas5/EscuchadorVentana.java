/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cerrarventanas5;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author mourelle
 */
public class EscuchadorVentana extends WindowAdapter {
    
    @Override
    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    
}
