/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variables;

/**
 *
 * @author mourelle
 */
public class Variables {
    
    /* Dentro de la clase, la variable es de instancia. Sólo existe cuando creo
    una instancia de la clase (un objeto) y cada instancia tendrá su propia
    copia. */
    private short soyInstancia;
    /* Una variable de instancia definida como private sólo puede utilizarse
    dentro de la propia clase. El resto de las clases del proyecto no pueden
    acceder a ella. Este es el concepto de encapsulación. */
    
    /* También dentro de la case, pero con la palabra clave static, la variable
    será de clase. No necesita una instancia para existir. Se accede a ella con
    el nombre de la clase. Y hay solamente una copia de la variable. */
    public static long soyClase;
    /* Un nivel de acceso public permite acceder a la variable desde cualquier
    clase del proyecto sin importar el paquete. */

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Dentro de un método, las variables son locales. Sólo existen en el
        contexto del propio método. Los argumentos del método también se
        consideran locales. */
        float soyFloat;
        double soyDouble;
        
        /* El tipo de datos primitivo char almacena un único caracter del
        conjunto Unicode. */
        char soyChar;
        /* Podemos inicializar una variable con el operador de asignación (=)
        y el valor correspondiente a continuación. Los caracteres escritos
        desde el teclado tienen que ir delimitados por comillas simples. */
        soyChar = 'A';
        /* También se puede escribir su valor unicode después de la barra
        invertida y una u. También se puede inicializar una variable en el
        momento de declararla. */
        char soyUnicode = '\u0539';
        /* Imprimo en la consola ambas variables. */
        System.out.println(soyChar);
        System.out.println(soyUnicode);
        
        /* Las cadenas de caracteres se manipulan mediante objetos de la clase
        String. Afortunadamente, Java nos permite manejar estas variables como
        si fueran tipos primitivos. */
        String soyString = "Tengo una muñeca vestida de azul";
        System.out.println(soyString);
        
        /* Los tipos booleanos sólo pueden tener dos valores: true (verdadero)
        o false (falso). */
        boolean soyBooleano = true;
        
        /* Antes de utilizar una variable local hay que inicializarla. Si no,
        se produce un error. */
        soyDouble = 1234567890.12345;
        System.out.println(soyDouble);
        
        /* Por defecto, java toma todos los números decimales como double. Si
        estoy haciendo una asignación para una variable de tipo float, existe
        una posible pérdida de información, por lo que se produce un error. Si
        yo lo que quiero es escribir un número en tamaño float, debo añadir al
        final del número una letra f ó F. */
        soyFloat = 12345.6789f;
        
        /* Java realiza una conversión implícita de tipos cuando intentamos
        introducir un valor de un tipo de datos pequeño dentro de otro más
        grande. Sin embargo, al revés puede haber pérdida de información y se
        produce un error. A menos que utilicenos una conversión explícita de
        los tipos de datos. Para ello, ponemos el tipo de datos al que queremos
        convertir entre paréntisis antes de la variable.*/
        byte peque;
        long grande = 123;
        peque = (byte)grande;
        
        /* Para convertir un tipo de datos primitivo en cadena de caracteres
        (String) debemos utilizar el método valueOf de la clase String. Se
        trata de un método de clase. */
        String cadena = String.valueOf(soyFloat);
        System.out.println(cadena);
        
        /* Para convertir una cadena en un tipo de datos primitivo debemos usar
        la clase disponible para ese tipo de datos y el método parseXxx()
        correspondiente. */
        String numeroCadena = "1234";
        int numero = Integer.parseInt(numeroCadena);
        
        /* Una constante almacena un valor que no puede ser modificado a lo
        largo del programa. Es obligatorio definirla con la palabra clave final
        y asignar un valor en el momento de su declaración. Recordad que las
        constantes se escriben todo en mayúsculas. */
        final double IVA = 1.21;
        /* Si intento modificar el valor de una constante, se produce un 
        error. */
        
    } // Final del método main
    
} // Final de la clase
