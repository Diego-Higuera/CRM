/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sinrenderizador;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    public Pantalla() {
    
        this.setTitle("Sin renderizador");
        this.setSize(466, 489);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        /* Evitar que el cuadro de diálogo se redimensione. */
        this.setResizable(false);
        
        
        JPanel panel = new JPanel();
        /* Renunciamos al renderizador. */
        panel.setLayout(null);
        
        JButton b1 = new JButton("Botón 1");
        /* Colocamos el botón manualmente. */
        b1.setLocation(0, 0);
        b1.setSize(150, 150);
        panel.add(b1);
        
        JButton b2 = new JButton("Botón 2");
        b2.setBounds(150, 150, 150, 150);
        panel.add(b2);
        
        JButton b3 = new JButton("Botón 3");
        b3.setBounds(300, 300, 150, 150);
        panel.add(b3);
        
        this.getContentPane().add(panel);
        
    } // Fin del constructor.
    
} // Fin de la clase.
