/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package componentesgraficos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    JLabel leyendaCuadro;
    boolean oculto = true;
    JLabel lblMuestra;
    
    public Pantalla() {
        
        this.setTitle("Componentes gráficos");
        this.setSize(1000,600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /* Panel intermedio. */
        JPanel panel = new JPanel();
        /* Damos color al panel para constatar que las etiquetas que vamos a
        añadir son transparentes. */
        panel.setBackground(new Color(212,172,13));
        /* El renderizador del panel es por defecto FlowLayout. vamos a cambiar
        la alineación a la izquierda. */
/*        FlowLayout fl = new FlowLayout();
        fl.setAlignment(FlowLayout.LEFT);
        panel.setLayout(fl); */
        ((FlowLayout)panel.getLayout()).setAlignment(FlowLayout.LEFT);
        
        /* Una etiqueta que muestra un texto en la ventana que no se puede
        modificar. */
        JLabel leyenda = new JLabel("Texto en la ventana");
        /* Le ponemos un borde a la etiqueta. */
        leyenda.setBorder(BorderFactory.createEtchedBorder());
        /* Especificamos también un tamaño para la etiqueta. En este caso, el
        método necesario es setPreferredSize, en lugar de setSize. */
        leyenda.setPreferredSize(new Dimension(300,200));
        /* Subimos el tamaño de letra. */
        leyenda.setFont(new Font("Verdana", Font.BOLD,16));
        /* Podemos especificar la posición del texto dentro del componente. */
        leyenda.setHorizontalAlignment(SwingConstants.RIGHT);
        leyenda.setVerticalAlignment(SwingConstants.BOTTOM);
        /* También podemos utilizar el componente JLabel para m ostrar imágenes
        o iconos. Emplearemos el método setIcon. La ruta del icono debe ser
        completa a partir de la carpeta src (incluida);*/
        leyenda.setIcon(new ImageIcon("src/imagenes/icono.png"));
        /* Separación entre el icono y el texto. */
        leyenda.setIconTextGap(40);
        /* Añadimos la etiqueta al panel. */
        panel.add(leyenda);
        
        /* Un botón para probar la interactividad con la leyenda. */
        JButton btnLeyenda = new JButton("Cambiar leyenda");
        btnLeyenda.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Pedimos un texto para sustituir al de la etiqueta. */
                String texto = JOptionPane.showInputDialog(
                        null, 
                        "Escriba un texto", 
                        "Texto para la leyenda", 
                        JOptionPane.QUESTION_MESSAGE);
                /* Mensaje diciendo cuál va a ser la sustitución. */
                JOptionPane.showMessageDialog(
                        null, 
                        "Vamos a sustituir '" + leyenda.getText() 
                                + "' por '" + texto + "'", 
                        "Sustitución", 
                        JOptionPane.INFORMATION_MESSAGE);
                leyenda.setText(texto);
            }
        });
        panel.add(btnLeyenda);
        
        /* Barra de progreso. */
        JProgressBar progreso = new JProgressBar();
        /* Establecer el máximo y el mínimo de la barra. */
        progreso.setMinimum(0);
        progreso.setMaximum(100);
        progreso.setValue(50);
        /* También podemos añadir una leyenda dentro de la barra de progreso,
        pero su visualización se controla con el método setStringPainted*/
        progreso.setString("50%");
        progreso.setStringPainted(true);
        /* También podemos poner la barra en un estado indeterminado con el
        método setIntedeterminate. */
        JProgressBar indeterminada = new JProgressBar();
        indeterminada.setPreferredSize(new Dimension(200,25));
        indeterminada.setIndeterminate(true);
        panel.add(progreso);
        panel.add(indeterminada);
        
        /* Cuadros de texto. Podemos especificar en el momento de su creación
        el número de columnas que abarca. */
        JTextField cuadro = new JTextField(20);
        /* O bienpodemos indicar su tamaño con setPreferredSize. */
        cuadro.setPreferredSize(new Dimension(150,30));
        cuadro.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                /* Cuando se pulse una tecla, voy a leer el contenido del
                cuadro. */
                String contenido = cuadro.getText();
                /* Vuelco este texto en la leyenda. */
                leyendaCuadro.setText(contenido);
            }
        });
        
        panel.add(cuadro);
        leyendaCuadro = new JLabel("No hay nada escrito");
        panel.add(leyendaCuadro);
        
        /* Cuadro de contraseña. Es como un JTextField pero podemos enmascarar
        el texto que se escribe. */
        JPasswordField password = new JPasswordField(10);
        password.setPreferredSize(new Dimension(150,30));
        /* Lo interesante en este control es el carácter que utilicemos para
        enmascarar el texto. */
        password.setEchoChar('*');
        panel.add(password);
        
        JButton ojo = new JButton();
        ojo.setIcon(new ImageIcon("src/imagenes/ojoabierto.png"));
        ojo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( oculto ) {
                    /* Si está oculto, muestro la contraseña. */
                    password.setEchoChar((char)0);
                    /* Cambio el icono del botón. */
                    ojo.setIcon(new ImageIcon("src/imagenes/ojocerrado.png"));
                    oculto = false;
                } else {
                    password.setEchoChar('*');
                    ojo.setIcon(new ImageIcon("src/imagenes/ojoabierto.png"));
                    oculto = true;
                }
            }
        });
        panel.add(ojo);
        
        /* Área de texto (texto en varias líneas. */
        JTextArea area = new JTextArea(5,15);
        JScrollPane desplaza = new JScrollPane(area);
        /* Esto gestiona las barras de desplazamiento, pero no gestiona el corte
        entre líneas. */
        area.setLineWrap(true);
        /* Para partir las líneas por palabras. */
        area.setWrapStyleWord(true);
        panel.add(desplaza);
        
        /* Botones. Responden al escuchador ActionListener. */
        JButton boton = new JButton("Botón");
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(
                        null, 
                        "¡Hola mundo!", 
                        "Mensaje", 
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        panel.add(boton);
        
        /* Barras de herramientas. */
        JMenuBar barraMenu = new JMenuBar();
        JMenu mnuFichero = new JMenu("Fichero");
        JMenuItem itNuevo = new JMenuItem("Nuevo");
        mnuFichero.add(itNuevo);
        JMenuItem itAbrir = new JMenuItem("Abrir");
        mnuFichero.add(itAbrir);
        JMenu mnuSalvaguardar = new JMenu("Salvaguardar");
        JMenuItem itGuardar = new JMenuItem("Guardar");
        mnuSalvaguardar.add(itGuardar);
        JMenuItem itGuardarComo = new JMenuItem("Guardar como");
        mnuSalvaguardar.add(itGuardarComo);
        mnuFichero.add(mnuSalvaguardar);
        /* Un separador. */
        mnuFichero.add(new JSeparator());
        JMenuItem itSalir = new JMenuItem("Salir");
        itSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        mnuFichero.add(itSalir);
        barraMenu.add(mnuFichero);
        
        JMenu mnuEdicion = new JMenu("Edición");
        JMenuItem itCopiar = new JMenuItem("Copiar");
        mnuEdicion.add(itCopiar);
        JMenuItem itCortar = new JMenuItem("Cortar");
        mnuEdicion.add(itCortar);
        JMenuItem itPegar = new JMenuItem("Pegar");
        mnuEdicion.add(itPegar);
        barraMenu.add(mnuEdicion);

        this.setJMenuBar(barraMenu);
        
        /* Barra de herramientas. */
        JToolBar herramientas = new JToolBar();
        /* La barra por defecto se puede hacer flotante. Si quiero evitar este
        comportamiento, utilizo setFloatable(). */
        herramientas.setFloatable(false);
        JButton btnWifi = new JButton(new ImageIcon("src/imagenes/b1.jpg"));
        herramientas.add(btnWifi);
        JButton btnCasa = new JButton(new ImageIcon("src/imagenes/b2.jpg"));
        btnCasa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(
                        null, 
                        "¡Ya estoy en casa!", 
                        "Mensaje", 
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        herramientas.add(btnCasa);
        JButton btnCandado = new JButton(new ImageIcon("src/imagenes/b3.jpg"));
        herramientas.add(btnCandado);
        /* Aunque no es recomendable, añadimos la barra de herramientas a la
        zona norte del ContentPane. */
        this.getContentPane().add(herramientas,BorderLayout.NORTH);
        
        /* Casillas de verificación. */
        JCheckBox chkCasilla = new JCheckBox("Casilla");
        /* Hacer el fondo de la casilla transparente. */
        chkCasilla.setBackground(null);
        panel.add(chkCasilla);
        /* Hacemos un botón que compruebe si la casilla está seleccionada o no
        está seleccionada. */
        JButton btnComprobar = new JButton("Comprobar");
        btnComprobar.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if ( chkCasilla.isSelected() ) {
                    JOptionPane.showMessageDialog(
                            null, 
                            "La casilla está seleccionada", 
                            "Comprobación", 
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(
                            null, 
                            "La casilla NO está seleccionada", 
                            "Comprobación", 
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        panel.add(btnComprobar);
        
        /* Los botones de opción o botones de radio permiten crear un grupo de
        opciones excluyentes entre sí, es decir, sólo puede haber una opción
        seleccionada al mismo tiempo y siempre debería haber una opción
        seleccionada. */
        JRadioButton btnContado = new JRadioButton("Contado");
        btnContado.setSelected(true);
        btnContado.setBackground(null);
        JRadioButton btnTarjeta = new JRadioButton("Tarjeta");
        btnTarjeta.setBackground(null);
        JRadioButton btnBizum   = new JRadioButton("Bizum");
        btnBizum.setBackground(null);
        /* Tenemos que agruparlos de una manera lógica para que pertenezcan al
        mismo grupo. */
        ButtonGroup grpPago = new ButtonGroup();
        /* Añado los botones al grupo. */
        grpPago.add(btnContado);
        grpPago.add(btnTarjeta);
        grpPago.add(btnBizum);
        /* Agrupación física de los botones. */
        JPanel panelPago = new JPanel();
        panelPago.setBackground(null);
        panelPago.setLayout(new GridLayout(3,1));
        panelPago.add(btnContado);
        panelPago.add(btnTarjeta);
        panelPago.add(btnBizum);
        /* Borde del panel. */
        panelPago.setBorder(BorderFactory.createTitledBorder
                (BorderFactory.createEtchedBorder(),"Forma de pago:"));
        /* Añado el panel de forma de pago al panel principal. */
        panel.add(panelPago);
        
        /* Un botón que nos diga cuál es la forma de pago seleccionada. */
        JButton btnForma = new JButton("Forma de pago");
        btnForma.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String mensaje = "Forma de pago: ";
                if ( btnContado.isSelected() ) {
                    mensaje += "contado";
                }
                if ( btnTarjeta.isSelected() ) {
                    mensaje += "tarjeta";
                }
                if ( btnBizum.isSelected() ) {
                    mensaje += "bizum";
                }
                JOptionPane.showMessageDialog(
                        null, 
                        mensaje, 
                        "Forma de pago", 
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        /* Añadimos el boton al panel. */
        panel.add(btnForma);
        
        /* Las listas ofrecen un conjunto de opciones en el que podemos
        seleccionar una o varias. Las listas JList no pueden gestionar por sí
        mismas las barras de desplazamiento, por lo que tendremos que ubicarlas
        dentro de un JScrollPane. Vamos a estudiar dos tipos de lista. El
        primero de ellos, recibe los elementos de la lista en el momento de su
        creación y, por tanto, es una lista estática. No se pueden añadir nuevos
        elementos a ella. */
        String[] fuentes = {"Arial", "Algerian", "Calibri", "Stencil",
            "Courier New","Verdana"};
        /* Creamos la lista con los elementos del array. */
        JList lstFuentes = new JList(fuentes);
        /* Podemos seleccionar una opción por defecto en la lista. */
        lstFuentes.setSelectedIndex(0);
        /* Insertamos la lista dentro de un JScrollPane para gestionar las
        barras de desplazamiento. */
        JScrollPane despFuentes = new JScrollPane(lstFuentes);
        /* Le damos un tamaño a la lista. */
        despFuentes.setPreferredSize(new Dimension(100,60));
        /* Por defecto, las listas son de selección múltiple, pero si queremos
        cambiar este comportamiento podemos hacerlas de selección única. */
        lstFuentes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        /* Gestionar los eventos de la lista. Reaccionar cuando cambie el
        elemento seleccionado en la lista. */
        lstFuentes.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                /* Cuando cambiamos de opción en la lista, se producen varios
                eventos. Para recuperar el valor seleccionado, tengo que
                asegurarme de que todos estos cambios han finalizado. */
                if ( !e.getValueIsAdjusting() ) {
                    /* Puedo leer el valor seleccionado. */
                    lblMuestra.setFont(new Font(lstFuentes.getSelectedValue()
                            .toString(),Font.BOLD,16));
                }
            }
        });
        /* Añadimos la lista al panel principal. */
        panel.add(despFuentes);
        
        /* Zona de muestra. */
        lblMuestra = new JLabel("Zona de muestra");
        lblMuestra.setBorder(BorderFactory.createEtchedBorder());
        lblMuestra.setHorizontalAlignment(SwingConstants.CENTER);
        lblMuestra.setVerticalAlignment(SwingConstants.CENTER);
        lblMuestra.setPreferredSize(new Dimension(200,100));
        lblMuestra.setFont(new Font("Arial", Font.BOLD,16));
        panel.add(lblMuestra);

        /* También podemos crear listas dinámicas a las que se pueden añadir
        nuevos elementos, utilizando como contenido de dicha lista un objeto
        DefaultListModel. */
        DefaultListModel model = new DefaultListModel();
        JList lstFrutas = new JList(model);
        /* Añadir elementos al modelo de la lista. */
        model.addElement("Manzana");
        model.addElement("Plátano");
        model.addElement("Melocotón");
        model.addElement("Pera");
        model.addElement("Uva");
        model.addElement("Kiwi");
        /* Seleccionar un elemento de la lista por defecto. */
        lstFrutas.setSelectedIndex(0);
        /* Creamos un JScrollPane para insertar en él la lista y que podamos
        gestionar las barras de desplazamiento. */
        JScrollPane despFrutas = new JScrollPane(lstFrutas);
        despFrutas.setPreferredSize(new Dimension(100,60));
        lstFrutas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.add(despFrutas);
        
        /* Un botón para añadir frutas a la lista. */
        JButton btnFrutas = new JButton("Añadir fruta");
        btnFrutas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Pido el nombre de la fruta. */
                String fruta = JOptionPane.showInputDialog(
                        null, 
                        "Escriba una nueva fruta", 
                        "Nueva fruta", 
                        JOptionPane.QUESTION_MESSAGE);
                model.addElement(fruta);
            }
        });
        panel.add(btnFrutas);

        /* Un combo-box (JComboBox) es una mezcla de un cuadro de texto, un
        botón y una lista. El usuario puede elegir un elemento de la lista o
        escribir su propia opción en el cuadro de texto. Si queremos que sólo
        se puedan seleccionar elmentos de la lista, deshabilitaremos el cuadro
        de texto con setEditable(false). Recuperaremos el elemento seleccionado
        de una forma similar a JList. Aquí, no hay selección múltiple. Los
        eventos de la lista se controlan con actionPerformed. Se activa al
        seleccionar un elemento o al pulsar la tecla Intro. */
        String[] tamanos = {"10","12","14","16","18","20"};
        JComboBox cboTamanos = new JComboBox(tamanos);
        cboTamanos.setEditable(true);
        cboTamanos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Leemos el valor de tamaño de la lista. */
                int tamano = Integer.parseInt(cboTamanos.getSelectedItem()
                        .toString());
                /* Cambiamos el tamaño de letra del cuadro de muestra leyendo
                la fuente de la lista lstFuentes, y especificando el nuevo
                tamaño leido del ComboBox. */
                lblMuestra.setFont(new Font(lstFuentes.getSelectedValue()
                            .toString(),Font.BOLD,tamano));
            }
        });
        panel.add(cboTamanos);
        
        this.getContentPane().add(panel);
        
    } // Fin del constructor.
    
} // Fin de la clase.
