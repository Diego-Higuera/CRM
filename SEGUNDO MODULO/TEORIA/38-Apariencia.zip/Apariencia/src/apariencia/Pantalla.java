/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apariencia;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mourelle
 */
public class Pantalla extends JFrame {
    
    JButton b1, b2, b3;
    
    public Pantalla() {
        
        this.setTitle("Apariencia");
        this.setSize(1000,800);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel panel = new JPanel();
        /* Esta es la forma de especificar un color a partir de sus componentes
        RGB decimales. */
        panel.setBackground(new Color(39,174,96));
        panel.setBackground(new Color(0xFABADA));
        
        b1 = new JButton("Botón 1");
        /* Cambio de tipografía. */
        b1.setFont(new Font("Times New Roman",Font.BOLD,30));
        /* Apariencia del cursor cuando se sitúa sobre el control. */
        b1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.add(b1);

        b2 = new JButton("Botón 2");
        /* Cambio de tipografía. */
        b2.setFont(new Font("Times New Roman",Font.BOLD,30));
        /* Apariencia del cursor cuando se sitúa sobre el control. */
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setEnabled(false);
        /* Al no estar habilitado, debería no ser focusable, es decir, no
        poder recibir el foco. Eso es así en la práctica, pero el método
        isFocusable no devuelve false, aunque el botón no puede recibir el
        foco, a menos que lo expresemos explícitamente con: */
        b2.setFocusable(false);
        panel.add(b2);
        
        b3 = new JButton("Botón 3");
        /* Cambio de tipografía. */
        b3.setFont(new Font("Times New Roman",Font.BOLD,30));
        /* Apariencia del cursor cuando se sitúa sobre el control. */
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        /* Esto sólo funciona una vez cargada la ventana. */
        b3.requestFocus();
        panel.add(b3);
        
        this.getContentPane().add(panel);
        
    } // Final del constructor.
    
    public JButton getB1() {
        return b1;
    }
    
    public JButton getB2() {
        return b2;
    }
    
    public JButton getB3() {
        return b3;
    }
    
    
} // Final de la clase.
