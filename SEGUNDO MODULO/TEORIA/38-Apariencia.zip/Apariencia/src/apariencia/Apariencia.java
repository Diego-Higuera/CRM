/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apariencia;

/**
 *
 * @author mourelle
 */
public class Apariencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Pantalla ventana = new Pantalla();
        ventana.setVisible(true);
        
        /* Compruebo si los componentes pueden adquirir el foco o no. Aunque
        por algún motivo no funciona correctamente.
        */
        System.out.println(ventana.getB1().isFocusable());
        System.out.println(ventana.getB2().isFocusable());
        /* Pido el foco para el tercer botón. */
        ventana.getB3().requestFocus();
        /* Puedo comprobar si el botón 3 tiene el foco. También debería 
        funcionar pero, por algún motivo esotérico y misterioso digno del
        programa de Cuarto Milenio, no funciona. Procedemos a llamar a Iker
        Jiménez a ver qué nos propone. */
        System.out.println(ventana.getB3().isFocusOwner());
        

    } // Final del método main().
    
} // Final de la clase.
