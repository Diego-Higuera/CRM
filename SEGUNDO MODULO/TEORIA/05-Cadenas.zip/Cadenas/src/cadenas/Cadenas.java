/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadenas;

/**
 *
 * @author mourelle
 */
public class Cadenas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Java manipula las cadenas mediante la clase String. Pero permite
        manejarlas como si fueran un tipo primitivo y no un objeto. Es posible
        crear un objeto String como si fuera un tipo primitivo o utilizar el
        operador new para hacerlo. */
        String cancion1 = "Al corro de la patata, comeremos ensalada.";
        String cancion2 = new String("Lo que comen los señores, "
                + "patatitas y limones");
        
        /* Las cadenas deben ir delimitadas por comillas dobles. Si necesitamos
        usar esas comillas en el contenido, debemos escaparlas. */
        String texto = "Y el cuervo dijo \"nunca más\".";
        System.out.println(texto);
        
        /* Para extraer el caracter que hay en una posición determinada de una
        cadena, utilizamos el método charAt(). Recordemos que el primer índice
        es el cero. El método devuelve un tipo char. */
        char caracter = texto.charAt(2);
        System.out.println(caracter);
        
        /* La longitud de una cadena se obtiene con el método length(). */
        int longitud = texto.length();
        System.out.println("La longitud de la cadena es " + longitud);
        
        /* Extraer una subcadena de una cadena principal. Utilizaremos el
        método substring() en el que especificaremos la posición de inicio y la 
        posición final (no incluida) del fragmento que deseamos extraer. */
        String fragmento = texto.substring(17, 28);
        System.out.println(fragmento);
        
        /* Las cadenas de caracteres no se pueden comparar con el operador de
        comparación (==) ya que no son tipos primitivos si no objetos. Para
        hacer la comparación, tendremos que usar el método equals de la clase
        String, que devuelve true o false según si las cadenas son iguales o no.
        Obsérvese que este método distingue mayúsculas y minúsculas. Si no 
        deseamos este comportamiento, podemos usar el método equalsIgnoreCase().
        No obstante, todo depende de cómo declaremos las cadenas. Si las
        declaramos con el primer método, que asimila las cadenas a tipos de 
        datos primitivos, el compilador se da cuenta de que existen dos cadenas
        iguales y crea dos copias de la misma instancia. De esta manera, al
        comparar con el operador de igualdad, el resultado será true ya que
        estamos comparando el mismo objeto. Sin embargo, cuando declaramos las
        cadenas con el segundo método, el compilador crea dos instancias
        diferentes de la cadena y entonces es necesario comparar con el método
        equals. En resumen, cuando se trate de comparar objetos (incluidas las
        cadenas de caracteres) debemos utilizar el método equals. Y dejaremos
        el operador de igualdad para comparar los tipos de datos primitivos. */
        String cadena1 = "Hola mundo";
        String cadena2 = "Hola mundo";
        boolean resultado = (cadena1 == cadena2);
        System.out.println(resultado);
        String cadena4 = new String("Ayer ví un ovni");
        String cadena5 = new String("Ayer ví un ovni");
        boolean resultadoOperador = (cadena4 == cadena5);
        boolean resultadoEquals = (cadena4.equals(cadena5));
        System.out.println(resultadoOperador);
        System.out.println(resultadoEquals);
        
        /* Comprobar si una cadena empieza o termina por un fragmento determi-
        nado. Funciones startsWith y endsWith. */
        System.out.println(texto.startsWith("Y"));
        System.out.println(texto.endsWith("."));
        
        /* Para suprimir espacios en blanco delante y detrás de una cadena,
        usamos el método trim(). */
        String espacios = "       texto       ";
        System.out.println("*" + espacios + "*");
        System.out.println("*" + espacios.trim() + "*");
        
        /* Cambiar a mayúsculas y minúsculas con los métodos toUpperCase() y
        toLowerCase(). */
        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());
        
        /* El método indexOf() busca la primera aparición de un texto en la
        cadena y devuelve su posición o -1 si n o lo encuentra. */
        int posicion = texto.indexOf("cuervo");
        System.out.println(posicion);
        
        /* Para sustituir un texto por otro en una cadena usamos el método
        replace() donde especificamos el texto buscado y el texto a sustituir.
        */
        String mensaje = "Los solteros solemos soldar solamente solos.";
        System.out.println(mensaje.replace("sol", "astro"));
        
    } // Final del método main().
    
} // Final de la clase.
